<?php
/**
 * Example application configuration.
 *
 * Copy this file to config.php and replace every CHANGE_ME value with your own
 * credentials before using the autoresponder.
 *
 * @return array
 */
return array(
    // Password for the admin panel. Set plain text on first install; auto-hashed on first login.
    'admin_password' => 'CHANGE_ME',
    // Failed admin logins allowed before a temporary lockout.
    'admin_login_max_attempts' => 5,
    // Minutes to block admin login after too many failed attempts.
    'admin_login_lock_minutes' => 15,
    // Sender name seen by your subscribers.
    'from_name' => 'My Autoresponder',
    // Sender email used by the system to send messages.
    'from_email' => 'you@example.com',
    // Use external SMTP server when set to true.
    'smtp_enabled' => false,
    // SMTP host name.
    'smtp_host' => 'smtp-relay.brevo.com',
    // SMTP port.
    'smtp_port' => 587,
    // SMTP username.
    'smtp_username' => 'CHANGE_ME',
    // SMTP password.
    'smtp_password' => 'CHANGE_ME',
    // SMTP encryption: '', 'tls', or 'ssl'.
    'smtp_secure' => 'tls',
    // Maximum number of emails the SMTP provider allows per day.
    // Set to 0 to disable the local quota guard.
    'smtp_daily_limit' => 300,
    // Maximum number of items allowed in the persistent outbound queue at any
    // one time. Protects against unbounded disk and memory growth when send_global
    // is triggered repeatedly or a large list is enqueued faster than the cron
    // can drain it. Set to 0 to disable the cap (not recommended on shared hosting).
    'mail_queue_max_items' => 10000,
    // Secret key used to create automatic unsubscribe links and public form tokens.
    // This is the security root for every unsubscribe link and signup form token
    // (HMAC-SHA256). Replace with a long, random, unique string before going live,
    // and never change it once in production: doing so invalidates every previously
    // sent unsubscribe link. Example: 'a3f0c1b2...d9e8' (64 hex chars).
    'unsubscribe_secret' => 'CHANGE_ME_SECRET_TOKEN',
    // Public low-priority trigger key for external web crons (cron-job.org, etc.).
    // Only required if you use Option B in the admin's Cron Setup tab. Replace with
    // a long, random alphanumeric string before use. Once a remote service is
    // configured with it, keep it stable or update the service to match.
    // Example: 'trig_9f2a7c4b1e8d...'.
    'public_trigger_key' => 'CHANGE_ME_PUBLIC_TRIGGER',
    // Minimum interval (in minutes) between consecutive public web cron executions.
    'cron_public_interval_minutes' => 5,
    // Time zone used for dates, schedules, and sequences.
    'time_zone' => 'UTC',
    // Folder where lists, messages, and subscribers are stored.
    'data_dir' => __DIR__ . '/data',
    // Send limit per cron run (to avoid overloading shared hosting).
    'max_sends_per_run' => 10,
    // Seconds to wait between individual sends (pauses to avoid send limits).
    'send_delay_seconds' => 3,
    // Number of consecutive failures after which a subscriber is marked as bounced.
    'bounce_threshold' => 3,
    // Rate limiting for public forms: maximum submissions per IP within the time window.
    'rate_limit_max' => 5,
    // Rate limit window in seconds (default: 1 hour).
    'rate_limit_window' => 3600,
    // Folder where ZIP backups are stored.
    'backup_dir' => __DIR__ . '/data/backups',
    // Folder where daily support logs are stored.
    'logs_dir' => __DIR__ . '/logs',
    // Historical send and error log file.
    'mail_log' => __DIR__ . '/data/mail.log',
    // Default thank-you URL after signup. Leave blank if you do not want a redirect.
    'default_thank_you' => '',
);
