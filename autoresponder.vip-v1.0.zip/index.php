<?php
require __DIR__ . '/lib.php';
app_bootstrap();
redirect_to_https_if_needed();
config_require_secrets_or_exit_public();

$lists = load_lists_meta();
$selected = null;
if (isset($_GET['list'])) {
    $candidate = load_list($_GET['list']);
    // Only expose the list if it exists AND is marked public.
    // Treating a private list identically to a non-existent one prevents
    // slug enumeration: an attacker cannot distinguish "not found" from
    // "found but private" by comparing response content.
    if ($candidate && !empty($candidate['public'])) {
        $selected = $candidate;
    }
}

render_header('Public signup');

echo '<div class="grid">';
echo '<div class="card"><h2 class="mt-0">Lists</h2>';
if (!$lists) {
    echo '<p class="muted">No lists yet. Create one from the admin panel.</p>';
} else {
    foreach ($lists as $list) {
        if (empty($list['public'])) {
            continue;
        }
        $name = htmlspecialchars($list['name'], ENT_QUOTES, 'UTF-8');
        $description = isset($list['description']) ? trim($list['description']) : '';
        $description_html = $description !== '' ? htmlspecialchars($description, ENT_QUOTES, 'UTF-8') : 'No description available.';
        echo '<div class="mb-10">';
        echo '<strong>' . $name . '</strong>';
        echo '<div class="list-description">' . $description_html . '</div>';
        echo '<a href="?list=' . rawurlencode($list['slug']) . '">Open form</a>';
        echo '</div>';
    }
}
echo '</div>';

echo '<div class="card">';
if (!$selected) {
    echo '<h2 class="mt-0">Choose a list</h2>';
    echo '<p class="muted">Open any list from the left to see its signup form.</p>';
} else {
    $list_name = htmlspecialchars($selected['name'], ENT_QUOTES, 'UTF-8');
    $slug = htmlspecialchars($selected['slug'], ENT_QUOTES, 'UTF-8');
    echo '<h2 class="mt-0">' . $list_name . '</h2>';
    echo '<p class="muted">Signup form for <span class="pill">' . $slug . '</span></p>';
    echo '<form method="post" action="subscribe.php" class="card">';
    echo '<input type="hidden" name="form_token" value="' . htmlspecialchars(public_form_token($selected['slug']), ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="list" value="' . $slug . '">';
    echo '<div class="inline-hidden"><label>Website</label><input type="text" name="website" tabindex="-1" autocomplete="off"></div>';
    echo '<div class="split"><div><label>Name</label><input type="text" name="name" placeholder="Your name"></div><div><label>Email</label><input type="email" name="email" required placeholder="you@example.com"></div></div>';
    echo '<div class="mt-12"><button class="btn" type="submit">Subscribe</button></div>';
    echo '</form>';
    echo '<div class="mt-12 muted">Embed code is generated from the admin panel for this list.</div>';
}
echo '</div></div>';

render_footer();
