<?php
header('Location: admin.php?logout=1');
exit;
