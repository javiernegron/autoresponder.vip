<?php
require __DIR__ . '/lib.php';
app_bootstrap();
redirect_to_https_if_needed();
config_require_secrets_or_exit('html');
if (session_status() !== PHP_SESSION_ACTIVE) {
    secure_session_start();
}

$cfg = app_cfg();
/** @var array $cfg Application configuration array from app_cfg() */
$flash = '';
$error = '';

/**
 * Redirige y termina la ejecución de forma limpia.
 * Centraliza todos los header(Location)+exit para evitar duplicación.
 */
function app_redirect_and_exit(string $url): void {
    // Only allow relative internal redirects — never redirect to external URLs
    // amazonq-ignore-next-line
    if (preg_match('/^https?:\/\//i', $url)) {
        $url = 'admin.php';
    }
    header('Location: ' . $url);
    exit;
}

if (isset($_GET['logout'])) {
    // Verify the CSRF token passed in the logout URL to prevent forced-logout
    // attacks. An attacker embedding <img src="admin.php?logout=1"> cannot
    // know the session token, so the check will fail and the session is kept.
    $logout_token = isset($_GET['_csrf']) ? (string) $_GET['_csrf'] : '';
    if (!secure_equals(csrf_token(), $logout_token)) {
        // Invalid or missing token — silently redirect without logging out.
        app_log('warn', 'Admin logout blocked: invalid CSRF token from IP ' . (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '?'));
        app_redirect_and_exit('admin.php');
    }
    $_SESSION = array();
    session_unset();
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', array(
            'expires'  => time() - 42000,
            'path'     => $params['path'],
            'domain'   => $params['domain'],
            'secure'   => $params['secure'],
            'httponly' => true,
            'samesite' => 'Strict',
        ));
    }
    session_destroy();
    app_redirect_and_exit('admin.php');
}

if (isset($_POST['login'])) {
    $client_ip = admin_login_client_ip();
    $retry_after = 0;
    if (admin_login_is_locked($client_ip, $retry_after)) {
        $error = admin_login_lock_message($retry_after);
        app_log('warn', 'Admin login blocked (locked IP) from IP ' . $client_ip);
    } elseif (!csrf_check()) {
        $error = 'Invalid CSRF token.';
        app_log('warn', 'Admin login failed: invalid CSRF from IP ' . $client_ip);
    } else {
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        if (admin_verify_password($password)) {
            admin_login_clear_attempts($client_ip);
            if (!admin_password_is_hashed((string) app_cfg()['admin_password'])) {
                if (!admin_password_upgrade_to_hash($password)) {
                    app_log('warn', 'Admin login OK but config.php is not writable; password was not auto-hashed');
                }
            }
            session_regenerate_id(true);
            $_SESSION['admin_logged_in'] = true;
            app_log('info', 'Admin login successful from IP ' . $client_ip);
            app_redirect_and_exit('admin.php');
        }
        admin_login_record_failure($client_ip);
        if (admin_login_is_locked($client_ip, $retry_after)) {
            $error = admin_login_lock_message($retry_after);
            app_log('warn', 'Admin login locked after failed attempts from IP ' . $client_ip);
        } else {
            $error = 'Wrong password.';
            app_log('warn', 'Admin login failed: wrong password from IP ' . $client_ip);
        }
    }
}

if (!admin_is_logged_in()) {
    // Render the login page and stop — no admin panel output follows.
    $login_ip = admin_login_client_ip();
    $login_retry_after = 0;
    $login_locked = admin_login_is_locked($login_ip, $login_retry_after);
    render_header('Admin login');
    if ($error !== '') {
        echo '<div class="warn">' . htmlspecialchars($error, ENT_QUOTES, 'UTF-8') . '</div>';
    } elseif ($login_locked) {
        echo '<div class="warn">' . htmlspecialchars(admin_login_lock_message($login_retry_after), ENT_QUOTES, 'UTF-8') . '</div>';
    }
    echo '<div class="card max-520">';
    echo '<h2 class="mt-0">Admin login</h2>';
    echo '<p class="muted">Enter your password to log in.</p>';
    if (!$login_locked) {
        echo '<form method="post">';
        echo csrf_field();
        echo '<input type="hidden" name="login" value="1">';
        echo '<label>Password</label><input type="password" name="password" required>';
        echo '<div class="mt-12"><button class="btn" type="submit">Login</button></div>';
        echo '</form>';
    }
    echo '</div>';
    render_footer();
} else {
    // Admin is authenticated — render the full administration panel.

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_check()) {
    $error = 'Invalid CSRF token.';
}

$allowed_tabs = array('lists', 'send', 'subscribers', 'run', 'backups');
$selected_tab = isset($_GET['tab']) ? sanitize_text($_GET['tab']) : 'lists';
if (!in_array($selected_tab, $allowed_tabs, true)) {
    $selected_tab = 'lists';
}
if (isset($_POST['tab'])) {
    $posted_tab = sanitize_text($_POST['tab']);
    if (in_array($posted_tab, $allowed_tabs, true)) {
        $selected_tab = $posted_tab;
    }
}

$selected_slug = isset($_GET['list']) ? $_GET['list'] : '';
if ($selected_slug !== '' && !valid_slug($selected_slug)) {
    $selected_slug = '';
}

$subscriber_slug = isset($_GET['subscribers_list']) ? $_GET['subscribers_list'] : '';
if ($subscriber_slug !== '' && !valid_slug($subscriber_slug)) {
    $subscriber_slug = '';
}

$create_name = '';
$create_slug = '';
$create_description = '';
$create_thank_you_url = '';
$message_subject = '';
$message_body = '';
$message_delay_days = 0;
$message_id = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';

    if ($action === 'create_list') {
        $name = sanitize_short_text(isset($_POST['name']) ? $_POST['name'] : '');
        $slug_input = sanitize_text(isset($_POST['slug']) ? $_POST['slug'] : '');
        $description = sanitize_short_text(isset($_POST['description']) ? $_POST['description'] : '');
        $thank_you_url = sanitize_text(isset($_POST['thank_you_url']) ? $_POST['thank_you_url'] : '');
        $slug = $slug_input !== '' ? normalize_slug($slug_input) : normalize_slug($name);
        $create_name = $name;
        $create_slug = $slug_input;
        $create_description = $description;
        $create_thank_you_url = $thank_you_url;
        if ($name === '') {
            $error = 'List name is required.';
        } elseif (!valid_slug($slug)) {
            $error = 'List slug is invalid.';
        } elseif (file_exists(list_path($slug))) {
            $error = 'That list already exists.';
        } elseif ($thank_you_url !== '' && (!preg_match('/^https?:\/\//i', $thank_you_url) || !is_safe_redirect_url($thank_you_url))) {
            $error = 'Thank you URL must belong to the same domain.';
        } else {
            $list = list_default(array('slug' => $slug, 'name' => $name));
            $list['description'] = $description;
            $list['settings']['thank_you_url'] = $thank_you_url;
            with_list_lock($slug, function () use ($list) {
                save_list($list);
            });
            app_redirect_and_exit('admin.php?tab=lists&list=' . rawurlencode($slug));
        }
    } elseif ($action === 'update_settings') {
        $slug = isset($_POST['list']) ? $_POST['list'] : '';
        if (!valid_slug($slug)) {
            $error = 'Invalid list identifier.';
            $selected_tab = 'lists';
        }
        $post_name = sanitize_short_text(isset($_POST['name']) ? $_POST['name'] : '');
        $post_description = sanitize_short_text(isset($_POST['description']) ? $_POST['description'] : '');
        $post_from_name = sanitize_short_text(isset($_POST['from_name']) ? $_POST['from_name'] : '');
        $post_from_email = sanitize_text(isset($_POST['from_email']) ? $_POST['from_email'] : '');
        $post_thank_you_url = sanitize_text(isset($_POST['thank_you_url']) ? $_POST['thank_you_url'] : '');
        $post_public = !empty($_POST['public']);
        if ($post_from_email !== '' && !filter_var($post_from_email, FILTER_VALIDATE_EMAIL)) {
            $error = 'From email is invalid.';
            $selected_slug = $slug;
            $selected_tab = 'lists';
        } elseif ($post_thank_you_url !== '' && (!preg_match('/^https?:\/\//i', $post_thank_you_url) || !is_safe_redirect_url($post_thank_you_url))) {
            $error = 'Thank you URL must belong to the same domain.';
            $selected_slug = $slug;
            $selected_tab = 'lists';
        }
        if ($error === '') {
            $saved = with_list_lock($slug, function () use ($slug, $post_name, $post_description, $post_from_name, $post_from_email, $post_thank_you_url, $post_public) {
                $list = load_list($slug);
                if (!$list) {
                    return false;
                }
                $list['name'] = $post_name !== '' ? $post_name : $list['name'];
                $list['description'] = $post_description !== '' ? $post_description : (isset($list['description']) ? $list['description'] : '');
                $list['settings']['from_name'] = $post_from_name !== '' ? $post_from_name : $list['settings']['from_name'];
                $list['settings']['from_email'] = $post_from_email !== '' ? $post_from_email : $list['settings']['from_email'];
                $list['settings']['thank_you_url'] = $post_thank_you_url;
                $list['public'] = $post_public;
                return save_list($list);
            });
            if (!$saved) {
                $error = 'List not found.';
            } else {
                $flash = 'Settings saved.';
                $selected_slug = $slug;
                $selected_tab = 'lists';
            }
        }
    } elseif ($action === 'save_message') {
        $slug = isset($_POST['list']) ? $_POST['list'] : '';
        if (!valid_slug($slug)) {
            $error = 'Invalid list identifier.';
            $selected_tab = 'lists';
        }
        $message_subject = sanitize_short_text(isset($_POST['subject']) ? $_POST['subject'] : '');
        $message_body = isset($_POST['body']) ? trim($_POST['body']) : '';
        $message_delay_days = intval(isset($_POST['delay_days']) ? $_POST['delay_days'] : 0);
        $message_id = isset($_POST['message_id']) ? $_POST['message_id'] : '';
        if ($message_delay_days < 0) {
            $message_delay_days = 0;
        }
        if ($message_subject === '' || $message_body === '') {
            $error = 'Subject and body are required.';
            $selected_slug = $slug;
            $selected_tab = 'lists';
        } elseif (!validate_body_length($message_body)) {
            $error = 'Message body is too large (maximum 100 KB).';
            $selected_slug = $slug;
            $selected_tab = 'lists';
        } else {
            $saved = with_list_lock($slug, function () use ($slug, $message_subject, $message_body, $message_delay_days, $message_id) {
                $list = load_list($slug);
                if (!$list) {
                    return false;
                }
                $message = array(
                    'id' => $message_id !== '' ? $message_id : make_id(),
                    'subject' => $message_subject,
                    'body' => $message_body,
                    'delay_days' => $message_delay_days,
                    'updated_at' => time(),
                );
                $updated = false;
                foreach ($list['messages'] as $idx => $existing) {
                    if ($message_id !== '' && isset($existing['id']) && $existing['id'] === $message_id) {
                        $list['messages'][$idx] = $message;
                        $updated = true;
                        break;
                    }
                }
                if (!$updated) {
                    $list['messages'][] = $message;
                }
                return save_list($list);
            });
            if (!$saved) {
                $error = 'List not found.';
            } else {
                $flash = 'Message saved.';
                $selected_slug = $slug;
                $selected_tab = 'lists';
            }
        }
    } elseif ($action === 'delete_message') {
        $slug = isset($_POST['list']) ? $_POST['list'] : '';
        $message_id = isset($_POST['message_id']) ? $_POST['message_id'] : '';
        if (!valid_slug($slug)) {
            $error = 'Invalid list identifier.';
            $selected_tab = 'lists';
        } else {
            with_list_lock($slug, function () use ($slug, $message_id) {
                $list = load_list($slug);
                if (!$list) {
                    return;
                }
                $next = array();
                foreach ($list['messages'] as $message) {
                    if (!isset($message['id']) || $message['id'] !== $message_id) {
                        $next[] = $message;
                    }
                }
                $list['messages'] = array_values($next);
                save_list($list);
            });
            $flash = 'Message deleted.';
            $selected_slug = $slug;
            $selected_tab = 'lists';
        }
    } elseif ($action === 'delete_list') {
        $slug = isset($_POST['list']) ? $_POST['list'] : '';
        if (!valid_slug($slug)) {
            $error = 'Invalid list identifier.';
            $selected_tab = 'lists';
        } else {
            with_list_lock($slug, function () use ($slug) {
                delete_list($slug);
            });
            app_redirect_and_exit('admin.php?tab=lists');
        }
    } elseif ($action === 'run_delivery') {
        $result = run_delivery_cycle();
        $flash = 'Delivery run complete. Sent ' . intval($result['sent']) . ' messages.';
        $selected_tab = 'run';
    } elseif ($action === 'clear_ratelimit') {
        rate_limit_clear(null);
        $flash = 'Cleared all rate limit entries.';
        $selected_tab = 'backups';
    } elseif ($action === 'clear_ratelimit_ip') {
        $ip = isset($_POST['ip']) ? sanitize_text($_POST['ip']) : '';
        if ($ip !== '') {
            rate_limit_clear($ip);
            $flash = 'Cleared rate limit for ' . $ip;
        }
        $selected_tab = 'backups';
    } elseif ($action === 'send_global') {
        $subject    = sanitize_short_text(isset($_POST['subject']) ? $_POST['subject'] : '');
        $body       = isset($_POST['body']) ? trim($_POST['body']) : '';
        // Apply safe_email_header() to strip CRLF sequences that sanitize_text()
        // does not remove — prevents header injection via the global send form.
        $from_name  = safe_email_header(sanitize_short_text(isset($_POST['global_from_name'])  ? $_POST['global_from_name']  : ''));
        $from_email = safe_email_header(isset($_POST['global_from_email']) ? $_POST['global_from_email'] : '');
        // Reject a non-empty from_email that fails address validation so the
        // admin gets clear feedback instead of a silent delivery failure.
        if ($from_email !== '' && !filter_var($from_email, FILTER_VALIDATE_EMAIL)) {
            $error = 'The "From email" field contains an invalid email address.';
            $selected_tab = 'send';
        }
        $targets = isset($_POST['target_lists']) ? $_POST['target_lists'] : array();
        if (!is_array($targets)) {
            $targets = array($targets);
        }
        if ($error !== '') {
            // from_email validation failed above — fall through to render the form with the error.
        } elseif ($subject === '' || $body === '') {
            $error = 'Subject and body are required for global send.';
        } elseif (!validate_body_length($body)) {
            $error = 'Message body is too large (maximum 100 KB).';
        } elseif (empty($targets)) {
            $error = 'Please select one or more lists.';
        } else {
            if (in_array('all', $targets, true)) {
                $lists_to_send = load_lists();
            } else {
                $lists_to_send = array();
                foreach ($targets as $t) {
                    $t = sanitize_text($t);
                    if (!valid_slug($t)) {
                        continue;
                    }
                    $lt = load_list($t);
                    if ($lt) {
                        $lists_to_send[] = $lt;
                    }
                }
            }
            if (empty($lists_to_send)) {
                $error = 'No valid lists selected.';
            } else {
                $dry_run = !empty($_POST['dry_run']);
                $would_send = 0;
                $sample = array();
                $queue_items = array();
                foreach ($lists_to_send as $list) {
                    foreach ($list['subscribers'] as $subscriber) {
                        $subscriber = ensure_subscriber_defaults($subscriber);
                        if (isset($subscriber['status']) && $subscriber['status'] !== 'active') {
                            continue;
                        }
                        if ($dry_run) {
                            $would_send++;
                            if (count($sample) < 10) {
                                $sample[] = $subscriber['email'];
                            }
                            continue;
                        }
                        $s_subject = merge_template($subject, $list, $subscriber);
                        $s_body = merge_template($body, $list, $subscriber);
                        $queue_items[] = array(
                            'id' => make_id(),
                            'kind' => 'global',
                            'created_at' => time(),
                            'due_at' => time(),
                            'to' => $subscriber['email'],
                            'subject' => $s_subject,
                            'body' => $s_body,
                            'from_name' => $from_name !== '' ? $from_name : $list['settings']['from_name'],
                            'from_email' => $from_email !== '' ? $from_email : $list['settings']['from_email'],
                            'list_slug' => $list['slug'],
                            'subscriber_email' => $subscriber['email'],
                            'attempts' => 0,
                            'last_error' => '',
                        );
                    }
                }
                if ($dry_run) {
                    $flash = 'Dry run: ' . intval($would_send) . ' recipients would receive the message.';
                    if (!empty($sample)) {
                        $flash .= ' Sample: ' . htmlspecialchars(implode(', ', $sample), ENT_QUOTES, 'UTF-8');
                    }
                    app_log('info', 'Global send dry-run to ' . intval($would_send) . ' recipients, lists=' . implode(',', array_map(function ($item) { return sanitize_text($item); }, $targets)));
                } else {
                    $enqueue_ok = true;
                    if (!empty($queue_items)) {
                        $enqueue_ok = mail_queue_enqueue_items($queue_items);
                    }
                    $queue_result = mail_queue_process();
                    $flash = 'Global send processed. Sent ' . intval($queue_result['sent']) . ' messages.';
                    if ($queue_result['queued'] > 0) {
                        $flash .= ' ' . intval($queue_result['queued']) . ' message(s) remain queued for the next available day.';
                    }
                    if (!empty($queue_result['quota_exhausted'])) {
                        $flash .= ' Daily SMTP quota exhausted; remaining items were deferred until tomorrow.';
                    }
                    if (!$enqueue_ok) {
                        $flash .= ' Warning: some recipients could not be queued because the queue size limit was reached. Check the daily log for details.';
                    }
                    app_log('info', 'Global send processed. Sent=' . intval($queue_result['sent']) . ' failed=' . intval($queue_result['failed']) . ' queued=' . intval($queue_result['queued']) . ' quota=' . (!empty($queue_result['quota_exhausted']) ? '1' : '0') . ' lists=' . implode(',', array_map(function ($item) { return sanitize_text($item); }, $targets)));
                }
            }
        }
        $selected_tab = 'send';
    } elseif ($action === 'download_csv') {
        $export_list = isset($_POST['list']) ? sanitize_text($_POST['list']) : '';
        $csv = generate_subscribers_csv($export_list !== '' ? $export_list : null);
        if ($csv === false) {
            $error = 'Unable to generate CSV export for selected list.';
        } else {
            // Build a safe filename: strip CRLF sequences (header injection defence)
            // and any double-quote characters (RFC 6266 quoted-string delimiter).
            // $export_list is already a validated slug ([a-z0-9-]) at this point,
            // so the cleanup is a defence-in-depth layer, not the primary gate.
            $raw_name   = $export_list !== '' ? $export_list : 'all';
            $safe_name  = str_replace('"', '', safe_email_header($raw_name));
            header('Content-Type: text/csv; charset=UTF-8');
            header('Content-Disposition: attachment; filename="subscribers-' . $safe_name . '.csv"');
            echo $csv;
            exit; // Stop execution after file output — prevents HTML being appended to the download.
        }
    } elseif ($action === 'download_backup') {
        $backup_file = isset($_POST['backup_file']) ? sanitize_text($_POST['backup_file']) : '';
        $backup_base = realpath(backup_dir());
        $safe_file = basename($backup_file);
        $full_path = $backup_base !== false ? realpath($backup_base . '/' . $safe_file) : false;
        if ($backup_file === '' || $full_path === false || strpos($full_path, $backup_base . DIRECTORY_SEPARATOR) !== 0 || !is_file($full_path)) {
            $error = 'Selected backup file was not found.';
        } else {
            // Strip CRLF sequences from the filename for header injection defence.
            // basename() already removes path separators; safe_email_header() removes
            // CR/LF. Double-quotes are removed to keep the quoted-string well-formed.
            $safe_dl_name = str_replace('"', '', safe_email_header($safe_file));
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $safe_dl_name . '"');
            header('Content-Length: ' . filesize($full_path));
            readfile($full_path);
            exit; // Stop execution after file output — prevents HTML being appended to the download.
        }
    } elseif ($action === 'create_backup') {
        $backupPath = create_backup_zip();
        if ($backupPath === false) {
            $error = 'Backup creation failed. ZipArchive may be unavailable.';
        } else {
            $flash = 'Backup created: ' . htmlspecialchars(basename($backupPath), ENT_QUOTES, 'UTF-8');
        }
        $selected_tab = 'backups';
    } elseif ($action === 'restore_backup') {
        $backup_file = isset($_POST['backup_file']) ? basename(sanitize_text($_POST['backup_file'])) : '';
        $backup_base = realpath(backup_dir());
        $full_restore_path = $backup_base !== false ? realpath($backup_base . '/' . $backup_file) : false;
        if ($backup_file === '' || $full_restore_path === false || strpos($full_restore_path, $backup_base . DIRECTORY_SEPARATOR) !== 0 || !restore_backup($backup_file)) {
            $error = 'Restore failed. Selected backup may be invalid.';
        } else {
            $flash = 'Backup restored: ' . htmlspecialchars($backup_file, ENT_QUOTES, 'UTF-8');
        }
        $selected_tab = 'backups';
    } elseif ($action === 'delete_backup') {
        $backup_file = isset($_POST['backup_file']) ? basename(sanitize_text($_POST['backup_file'])) : '';
        $backup_base = realpath(backup_dir());
        $full_delete_path = $backup_base !== false ? realpath($backup_base . '/' . $backup_file) : false;
        if ($backup_file === '' || $full_delete_path === false || strpos($full_delete_path, $backup_base . DIRECTORY_SEPARATOR) !== 0 || !delete_backup_file($backup_file)) {
            $error = 'Unable to delete backup file.';
        } else {
            $flash = 'Deleted backup: ' . htmlspecialchars($backup_file, ENT_QUOTES, 'UTF-8');
        }
        $selected_tab = 'backups';
    }
}

$lists = load_lists_meta();
$selected = $selected_slug !== '' ? load_list($selected_slug) : null;
$subscriber_selected = $subscriber_slug !== '' ? load_list($subscriber_slug) : null;
if (!$subscriber_selected && $selected) {
    $subscriber_selected = $selected;
}
$backup_files = list_backup_files();
$ratelimits = rate_limit_get_all();
$ratelimit_storage_error = rate_limit_get_storage_error();
$mail_queue = mail_queue_load();
mail_queue_sync_state($mail_queue);
$smtp_daily_limit = smtp_daily_limit();
$smtp_daily_remaining = mail_budget_remaining($mail_queue);
$smtp_daily_sent = isset($mail_queue['state']['sent']) ? intval($mail_queue['state']['sent']) : 0;
$smtp_queue_items = isset($mail_queue['items']) && is_array($mail_queue['items']) ? $mail_queue['items'] : array();
$smtp_queue_count = count($smtp_queue_items);
$smtp_queue_exhausted = !empty($mail_queue['state']['quota_exhausted']);
$smtp_queue_reason = isset($mail_queue['state']['quota_reason']) ? (string) $mail_queue['state']['quota_reason'] : '';
$smtp_queue_date = isset($mail_queue['state']['date']) ? (string) $mail_queue['state']['date'] : date('Y-m-d');
$smtp_queue_next_reset = date('Y-m-d H:i:s', mail_queue_next_reset_at());
$smtp_queue_max_items = isset($cfg['mail_queue_max_items']) ? intval($cfg['mail_queue_max_items']) : 10000;
$log_meta = read_log_tail_meta(daily_log_path(), 20, 65536);
$log_lines = isset($log_meta['lines']) ? $log_meta['lines'] : array();
$log_truncated = !empty($log_meta['truncated']);

// Preserve submitted form values for the global send form so dry-run doesn't clear them
$form_from_name = isset($_POST['global_from_name']) ? htmlspecialchars(sanitize_text($_POST['global_from_name']), ENT_QUOTES, 'UTF-8') : '';
$form_from_email = isset($_POST['global_from_email']) ? htmlspecialchars(sanitize_text($_POST['global_from_email']), ENT_QUOTES, 'UTF-8') : '';
$form_subject = isset($_POST['subject']) ? htmlspecialchars(sanitize_text($_POST['subject']), ENT_QUOTES, 'UTF-8') : '';
$form_body = isset($_POST['body']) ? htmlspecialchars(trim($_POST['body']), ENT_QUOTES, 'UTF-8') : '';
$form_targets = isset($_POST['target_lists']) ? (is_array($_POST['target_lists']) ? $_POST['target_lists'] : array($_POST['target_lists'])) : array();
$form_dry = !empty($_POST['dry_run']);

$e = function ($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
};
$paginate = function (array $items, $page, $per_page) {
    $allowed = array(10, 25, 50);
    $per_page = intval($per_page);
    if (!in_array($per_page, $allowed, true)) {
        $per_page = 10;
    }
    $page = max(1, intval($page));
    $total = count($items);
    $total_pages = max(1, (int) ceil($total / $per_page));
    if ($page > $total_pages) {
        $page = $total_pages;
    }
    $offset = ($page - 1) * $per_page;
    $rows = array_slice($items, $offset, $per_page);
    return array(
        'rows' => $rows,
        'total' => $total,
        'page' => $page,
        'per_page' => $per_page,
        'total_pages' => $total_pages,
        'start' => $total > 0 ? $offset + 1 : 0,
        'end' => $total > 0 ? min($total, $offset + $per_page) : 0,
    );
};
$tab_url = function ($tab, $params = array()) {
    $params['tab'] = $tab;
    return 'admin.php?' . http_build_query($params);
};
$subscriber_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$subscriber_per_page = isset($_GET['per_page']) ? intval($_GET['per_page']) : 10;
$subscriber_page_sizes = array(10, 25, 50);
if (!in_array($subscriber_per_page, $subscriber_page_sizes, true)) {
    $subscriber_per_page = 10;
}
$selected_list_url = $tab_url('lists');
$subscriber_list_url = $subscriber_selected ? $tab_url('subscribers', array('subscribers_list' => $subscriber_selected['slug'])) : $tab_url('subscribers');

render_header('Admin');

if ($error !== '') {
    echo '<div class="warn">' . $e($error) . '</div>';
}
if ($flash !== '') {
    echo '<div class="notice">' . $e($flash) . '</div>';
}

echo '<div class="section-nav">';
echo '<a class="' . ($selected_tab === 'lists' ? 'active' : '') . '" href="' . $selected_list_url . '">Lists</a>';
echo '<a class="' . ($selected_tab === 'send' ? 'active' : '') . '" href="' . $tab_url('send') . '">Send Messages</a>';
echo '<a class="' . ($selected_tab === 'subscribers' ? 'active' : '') . '" href="' . $subscriber_list_url . '">Subscribers</a>';
echo '<a class="' . ($selected_tab === 'run' ? 'active' : '') . '" href="' . $tab_url('run') . '">Cron Setup</a>';
echo '<a class="' . ($selected_tab === 'backups' ? 'active' : '') . '" href="' . $tab_url('backups') . '">Backups &amp; Logs</a>';
echo '</div>';

if ($selected_tab === 'send') {
    echo '<div class="section-grid">';
    echo '<div class="card">';
    echo '<h2 class="mt-0">Send global message</h2>';
    if (!$lists) {
        echo '<p class="muted">No lists are available yet.</p>';
    } else {
        echo '<p class="muted">Select one or more lists below. Choosing <strong>All list</strong> disables the individual list checkboxes.</p>';
        echo '<div class="checkbox-list" data-target-list-wrap>';
        $all_checked = in_array('all', $form_targets, true) ? ' checked' : '';
        echo '<label class="checkbox-row"><input type="checkbox" name="target_lists[]" value="all"' . $all_checked . ' data-target-all form="global-send-form"> All list</label>';
        foreach ($lists as $list) {
            $lslug = $e($list['slug']);
            $lname = $e($list['name']);
            $checked = in_array($list['slug'], $form_targets, true) ? ' checked' : '';
            echo '<label class="checkbox-row"><input type="checkbox" name="target_lists[]" value="' . $lslug . '"' . $checked . ' data-target-item form="global-send-form"> ' . $lname . ' <span class="muted">(' . $lslug . ')</span></label>';
        }
        echo '</div>';
    }
    echo '</div>';

    echo '<div class="card">';
    echo '<h2 class="mt-0">Message</h2>';
    echo '<form method="post" id="global-send-form">';
    echo csrf_field();
    echo '<input type="hidden" name="action" value="send_global">';
    echo '<input type="hidden" name="tab" value="send">';
    echo '<label>From name (optional)</label><input type="text" name="global_from_name" placeholder="Optional" value="' . $form_from_name . '">';
    echo '<label class="mt-10">From email (optional)</label><input type="email" name="global_from_email" placeholder="Optional" value="' . $form_from_email . '">';
    echo '<label class="mt-10">Subject</label><input type="text" name="subject" required placeholder="Subject" value="' . $form_subject . '">';
    echo '<label class="mt-10">Body</label><textarea name="body" rows="6" placeholder="Message body. You can use {{NAME}} and {{UNSUBSCRIBE_URL}}">' . $form_body . '</textarea>';
    echo '<div class="muted mt-6">Available merge fields. Click any field to copy it.</div>';
    echo '<div class="token-grid">';
    $tokens = array('{{NAME}}','{{FIRSTNAME}}','{{EMAIL}}','{{LIST}}','{{UNSUBSCRIBE_URL}}','{{SITE_URL}}');
    foreach ($tokens as $t) {
        $token = $e($t);
        $title = $e('Click to copy ' . $t);
        echo '<input type="text" readonly class="token" value="' . $token . '" title="' . $title . '" aria-label="' . $title . '">';
    }
    echo '</div>';
    echo '<p class="muted mt-10">Select Dry run to simulate sending the message without actually delivering emails; it shows how many recipients would receive it.</p>';
    $dry_checked = $form_dry ? ' checked' : '';
    echo '<label class="mt-10 checkbox-row"><input type="checkbox" name="dry_run" value="1"' . $dry_checked . '> Dry run</label>';
    echo '<div class="mt-12"><button class="btn" type="submit">Send global</button></div>';
    echo '</form>';
    echo '</div>';
    echo '</div>';
} elseif ($selected_tab === 'subscribers') {
    echo '<div class="section-grid">';
    echo '<div class="card">';
    echo '<h2 class="mt-0">Subscribers</h2>';
    if (!$lists) {
        echo '<p class="muted">No lists yet.</p>';
    } else {
        foreach ($lists as $list) {
            $lslug = $e($list['slug']);
            $lname = $e($list['name']);
            echo '<div class="list-item">';
            echo '<div class="list-item-main">';
            echo '<a class="list-link" href="' . $tab_url('lists', array('list' => $list['slug'])) . '">&#9881; ' . $lname . '</a>';
            echo '<div class="muted">' . $lslug . '</div>';
            echo '</div>';
            echo '<div class="list-item-actions">';
            echo '<a class="btn secondary small-btn" href="' . $tab_url('subscribers', array('subscribers_list' => $list['slug'])) . '">View subscribers</a>';
            echo '<a class="btn secondary small-btn" href="' . $tab_url('lists', array('list' => $list['slug'])) . '">Setup</a>';
            echo '</div>';
            echo '</div>';
        }
    }
    echo '</div>';
    echo '<div class="card">';
    if (!$subscriber_selected) {
        echo '<h2 class="mt-0">View subscribers</h2>';
        echo '<p class="muted">Select a list on the left to see its subscribers.</p>';
    } else {
        $sub_slug = $e($subscriber_selected['slug']);
        $sub_name = $e($subscriber_selected['name']);
        $subscriber_page_info = $paginate(isset($subscriber_selected['subscribers']) ? $subscriber_selected['subscribers'] : array(), $subscriber_page, $subscriber_per_page);
        $subscriber_rows = $subscriber_page_info['rows'];
        $subscriber_total = $subscriber_page_info['total'];
        $subscriber_page = $subscriber_page_info['page'];
        $subscriber_total_pages = $subscriber_page_info['total_pages'];
        $subscriber_start = $subscriber_page_info['start'];
        $subscriber_end = $subscriber_page_info['end'];
        $subscriber_base_params = array('tab' => 'subscribers', 'subscribers_list' => $subscriber_selected['slug'], 'per_page' => $subscriber_per_page);
        $subscriber_prev_url = $subscriber_page > 1 ? 'admin.php?' . http_build_query($subscriber_base_params + array('page' => $subscriber_page - 1)) : '';
        $subscriber_next_url = $subscriber_page < $subscriber_total_pages ? 'admin.php?' . http_build_query($subscriber_base_params + array('page' => $subscriber_page + 1)) : '';
        echo '<h2 class="mt-0">' . $sub_name . '</h2>';
        echo '<p class="muted">List slug: <span class="pill">' . $sub_slug . '</span></p>';
        if (empty($subscriber_rows)) {
            echo '<p class="muted">No subscribers yet.</p>';
        } else {
            echo '<div class="table-shell">';
            echo '<table><tr><th>Email</th><th>Name</th><th>Status</th><th>Next send</th></tr>';
            foreach ($subscriber_rows as $subscriber) {
                $email = $e(isset($subscriber['email']) ? $subscriber['email'] : '');
                $name  = $e(mb_strimwidth(isset($subscriber['name'])  ? $subscriber['name']  : '', 0, 60, '…', 'UTF-8'));
                $status = $e(isset($subscriber['status']) ? $subscriber['status'] : 'active');
                $next = !empty($subscriber['next_send_at']) ? date('Y-m-d H:i', intval($subscriber['next_send_at'])) : '-';
                echo '<tr><td>' . $email . '</td><td>' . $name . '</td><td>' . $status . '</td><td>' . $e($next) . '</td></tr>';
            }
            echo '</table>';
            echo '</div>';
            echo '<div class="pagination-panel">';
            echo '<div class="muted">Showing ' . intval($subscriber_start) . '-' . intval($subscriber_end) . ' of ' . intval($subscriber_total) . ' subscribers</div>';
            echo '<div class="pagination-controls">';
            if ($subscriber_prev_url !== '') {
                echo '<a class="btn secondary small-btn" href="' . $subscriber_prev_url . '">Previous</a>';
            }
            if ($subscriber_next_url !== '') {
                echo '<a class="btn secondary small-btn" href="' . $subscriber_next_url . '">Next</a>';
            }
            echo '</div>';
            echo '<form method="get" class="pagination-size-form">';
            echo '<input type="hidden" name="tab" value="subscribers">';
            echo '<input type="hidden" name="subscribers_list" value="' . $sub_slug . '">';
            echo '<input type="hidden" name="page" value="1">';
            echo '<label class="pagination-label" for="subscriber-per-page">Rows per page</label>';
            echo '<select id="subscriber-per-page" name="per_page" data-auto-submit>
';
            foreach ($subscriber_page_sizes as $size) {
                $selected_size = $subscriber_per_page === $size ? ' selected' : '';
                echo '<option value="' . intval($size) . '"' . $selected_size . '>' . intval($size) . '</option>';
            }
            echo '</select>';
            echo '</form>';
            echo '</div>';
        }
    }
    echo '</div>';
    echo '</div>';
} elseif ($selected_tab === 'run') {
    $cron_path = realpath(__DIR__ . '/cron.php');
    $public_trigger_url = $e(app_base_url() . '/cron.php?public_trigger=' . rawurlencode($cfg['public_trigger_key']));
    $cron_interval = intval(isset($cfg['cron_public_interval_minutes']) ? $cfg['cron_public_interval_minutes'] : 5);

    echo '<div class="run-mailing">';

    // Sección 1: Ejecución Manual
    echo '<div class="run-mailing__section card">';
    echo '<h2 class="mt-0">1. Manual Execution <span class="muted">(For Quick Tests)</span></h2>';
    echo '<p>Want to send your emails right now without waiting? You can trigger the mailing cycle immediately with a single click.</p>';
    echo '<p><strong>Note:</strong> You must keep this window open until the process finishes.</p>';
    echo '<form method="post" data-confirm="Run cron manually?">';
    echo csrf_field();
    echo '<input type="hidden" name="action" value="run_delivery">';
    echo '<input type="hidden" name="tab" value="run">';
    echo '<button class="btn" type="submit">Run Cron Manually</button>';
    echo '</form>';
    echo '</div>';

    // Sección 2: Automatización
    echo '<div class="run-mailing__section card">';
    echo '<h2 class="mt-0">2. Automated Delivery <span class="muted">(Recommended)</span></h2>';
    echo '<p>To allow your newsletters and autoresponders to automatically send in the background, you need to set up a <strong>scheduled task (Cron Job)</strong> to run <strong>every 1 minute</strong>. Choose one of the following three options based on your hosting service capabilities:</p>';


    // Opción A
    echo '<div class="run-mailing__option">';
    echo '<h3 class="run-mailing__option-title">Option A: From your Hosting Control Panel (cPanel, DirectAdmin, etc.)</h3>';
    echo '<p>If your hosting provider allows you to create &quot;Cron Jobs&quot; from its control panel, this is the most efficient and secure option.</p>';
    echo '<p><strong>Step 1:</strong> Log into your hosting control panel and look for the &quot;Cron Jobs&quot; section.<br>';
    echo '<strong>Step 2:</strong> Set the frequency to &quot;Every minute&quot; (or use the expression: <code>* * * * *</code>).<br>';
    echo '<strong>Step 3:</strong> In the &quot;Command&quot; field, copy and paste exactly the following line of code:</p>';
    echo '<input type="text" readonly class="copyable" value="php ' . $e($cron_path) . '" title="Click to copy" aria-label="CLI command for hosting cron">';
    echo '</div>';

    // Opción B
    echo '<div class="run-mailing__option">';
    echo '<h3 class="run-mailing__option-title">Option B: Using a Free External Service <span class="muted">(If your hosting lacks Cron support)</span></h3>';
    echo '<p>If your hosting plan does not include or has cron jobs disabled, you can use an external service to automatically &quot;wake up&quot; your autoresponder.</p>';
    echo '<p><strong>Step 1:</strong> Sign up for a free account at <a href="https://cron-job.org/en/" target="_blank" rel="noopener">cron-job.org</a>.<br>';
    echo '<strong>Step 2:</strong> Create a new &quot;Cronjob&quot; on their platform.<br>';
    echo '<strong>Step 3:</strong> In the URL field, enter this secure activation link:</p>';
    echo '<input type="text" readonly class="copyable" value="' . $public_trigger_url . '" title="Click to copy" aria-label="Public trigger URL">';
    echo '<p class="muted"><small>This link features anti-bot protection and rate limiting. The endpoint always responds with <code>204 No Content</code> — no system information is returned to the external service. Requests arriving more frequently than every ' . $cron_interval . ' minute(s) are silently ignored to preserve server resources.</small></p>';
    echo '</div>';

    // Opción C
    echo '<div class="run-mailing__option">';
    echo '<h3 class="run-mailing__option-title">Option C: Via Command Line <span class="muted">(VPS / Self-Managed Servers Only)</span></h3>';
    echo '<p>If you manage your own server via terminal (SSH), run or schedule the local script within your system&#39;s crontab using the PHP binary. Running internally requires no public authentication keys:</p>';
    echo '<input type="text" readonly class="copyable" value="php ' . $e($cron_path) . '" title="Click to copy" aria-label="CLI command for VPS">';
    echo '</div>';

    echo '</div>'; // .run-mailing__section (automatizacion)
    echo '</div>'; // .run-mailing
} elseif ($selected_tab === 'backups') {
    echo '<div class="section-grid">';
    echo '<div class="card">';
    echo '<h2 class="mt-0">Backup &amp; export</h2>';
    echo '<p class="muted">Create a ZIP backup of the autoresponder data folder, including subscriber lists, settings, rate limit data and saved backup files.</p>';
    echo '<form method="post" class="mb-10">';
    echo csrf_field();
    echo '<input type="hidden" name="action" value="create_backup">';
    echo '<input type="hidden" name="tab" value="backups">';
    echo '<button class="btn secondary" type="submit">Create ZIP backup</button>';
    echo '</form>';
    echo '<form method="post" class="mb-10">';
    echo csrf_field();
    echo '<input type="hidden" name="action" value="download_csv">';
    echo '<input type="hidden" name="tab" value="backups">';
    echo '<button class="btn secondary" type="submit">Export all subscribers as CSV</button>';
    echo '</form>';
    echo '<form method="post" class="mb-10">';
    echo csrf_field();
    echo '<input type="hidden" name="action" value="download_csv">';
    echo '<input type="hidden" name="tab" value="backups">';
    echo '<label>Export a single list</label>';
    echo '<select name="list">';
    echo '<option value="">Select a list</option>';
    foreach ($lists as $list) {
        $list_slug = $e($list['slug']);
        $list_name = $e($list['name']);
        echo '<option value="' . $list_slug . '">' . $list_name . ' (' . $list_slug . ')</option>';
    }
    echo '</select>';
    echo '<div class="mt-8"><button class="btn secondary" type="submit">Export selected list CSV</button></div>';
    echo '</form>';
    if (!empty($backup_files)) {
        echo '<table><tr><th>File</th><th>Action</th></tr>';
        foreach ($backup_files as $backup_file) {
            $safe_file = $e($backup_file);
            echo '<tr><td>' . $safe_file . '</td><td>';
            echo '<form method="post" class="table-actions__form">';
            echo csrf_field();
            echo '<input type="hidden" name="action" value="download_backup">';
            echo '<input type="hidden" name="tab" value="backups">';
            echo '<input type="hidden" name="backup_file" value="' . $safe_file . '">';
            echo '<button class="btn secondary btn-download" type="submit">Download</button>';
            echo '</form> ';
            echo '<form method="post" class="table-actions__form">';
            echo csrf_field();
            echo '<input type="hidden" name="action" value="restore_backup">';
            echo '<input type="hidden" name="tab" value="backups">';
            echo '<input type="hidden" name="backup_file" value="' . $safe_file . '">';
            echo '<button class="btn btn-restore" type="submit">Restore</button>';
            echo '</form> ';
            echo '<form method="post" class="table-actions__form" data-confirm="Delete this backup?">';
            echo csrf_field();
            echo '<input type="hidden" name="action" value="delete_backup">';
            echo '<input type="hidden" name="tab" value="backups">';
            echo '<input type="hidden" name="backup_file" value="' . $safe_file . '">';
            echo '<button class="btn danger btn-delete" type="submit">Delete</button>';
            echo '</form>';
            echo '</td></tr>';
        }
        echo '</table>';
    } else {
        echo '<p class="muted">No backups yet.</p>';
    }
    echo '</div>';
    echo '<div class="stack">';
    echo '<div class="card">';
    echo '<h2 class="mt-0">Mail Queue</h2>';
    echo '<p class="muted">Daily SMTP quota and deferred outbound messages are tracked here.</p>';
    echo '<div class="mail-queue-summary">';
    echo '<div class="mail-queue-summary__item"><div class="muted">Daily limit</div><div class="mail-queue-summary__value">' . ($smtp_daily_limit > 0 ? intval($smtp_daily_limit) : 'Unlimited') . '</div></div>';
    echo '<div class="mail-queue-summary__item"><div class="muted">Sent today</div><div class="mail-queue-summary__value">' . intval($smtp_daily_sent) . '</div></div>';
    echo '<div class="mail-queue-summary__item"><div class="muted">Remaining today</div><div class="mail-queue-summary__value">' . ($smtp_daily_remaining >= 0 ? intval($smtp_daily_remaining) : 'Unlimited') . '</div></div>';
    echo '<div class="mail-queue-summary__item"><div class="muted">Queued items</div><div class="mail-queue-summary__value">' . intval($smtp_queue_count) . '</div></div>';
    echo '<div class="mail-queue-summary__item"><div class="muted">Queue cap</div><div class="mail-queue-summary__value">' . ($smtp_queue_max_items > 0 ? intval($smtp_queue_max_items) : 'Unlimited') . '</div></div>';
    echo '<div class="mail-queue-summary__item"><div class="muted">Queue date</div><div class="mail-queue-summary__value">' . $e($smtp_queue_date) . '</div></div>';
    echo '<div class="mail-queue-summary__item"><div class="muted">Next reset</div><div class="mail-queue-summary__value">' . $e($smtp_queue_next_reset) . '</div></div>';
    echo '</div>';
    if ($smtp_queue_exhausted) {
        $reason_label = $smtp_queue_reason !== '' ? $smtp_queue_reason : 'quota_exhausted';
        echo '<div class="warn mt-12">SMTP quota is exhausted for today. Remaining queued messages will resume after the next reset. Reason: ' . $e($reason_label) . '</div>';
    } elseif ($smtp_queue_count > 0) {
        echo '<div class="notice mt-12">There are deferred messages waiting for the next available send window.</div>';
    } else {
        echo '<p class="muted mt-12">No queued outbound messages right now.</p>';
    }
    if ($smtp_queue_count > 0) {
        echo '<div class="mail-queue-list">';
        $sample_queue = array_slice($smtp_queue_items, 0, 8);
        foreach ($sample_queue as $queued_item) {
            $queued_to = isset($queued_item['to']) ? $e($queued_item['to']) : '?';
            $queued_subject = isset($queued_item['subject']) ? $e($queued_item['subject']) : '';
            $queued_due = isset($queued_item['due_at']) ? date('Y-m-d H:i:s', intval($queued_item['due_at'])) : '-';
            $queued_attempts = isset($queued_item['attempts']) ? intval($queued_item['attempts']) : 0;
            echo '<div class="mail-queue-list__item">';
            echo '<div class="mail-queue-list__main"><div class="mail-queue-list__email">' . $queued_to . '</div><div class="mail-queue-list__subject">' . $queued_subject . '</div></div>';
            echo '<div class="mail-queue-list__meta"><span class="pill">Due ' . $e($queued_due) . '</span><span class="pill">Attempts ' . $queued_attempts . '</span></div>';
            echo '</div>';
        }
        if ($smtp_queue_count > count($sample_queue)) {
            echo '<p class="muted mt-10">Showing the first ' . count($sample_queue) . ' queued items only.</p>';
        }
        echo '</div>';
    }
    echo '</div>';
    echo '<div class="card">';
    echo '<h2 class="mt-0">Recent logs</h2>';
    echo '<p class="muted">These are the latest autoresponder events and activity lines written today.</p>';
    if (empty($log_lines)) {
        echo '<p class="muted">No logs have been written today yet.</p>';
    } else {
        echo '<pre class="log-output">' . $e(implode("\n", $log_lines)) . '</pre>';
        if ($log_truncated) {
            echo '<p class="muted">Only the most recent log lines are shown here.</p>';
        }
    }
    echo '</div>';
    echo '<div class="card">';
    echo '<h2 class="mt-0">Rate limit (recent)</h2>';
    echo '<p class="muted">These are the most recent IP addresses and counts tracked by the rate limiter.</p>';
    if ($ratelimit_storage_error !== null) {
        $first_seen = isset($ratelimit_storage_error['first_seen_at']) ? date('Y-m-d H:i:s', intval($ratelimit_storage_error['first_seen_at'])) : '?';
        echo '<div class="warn"><strong>⚠ Rate limiting is disabled.</strong> The rate-limit storage file (<code>data/ratelimit.json</code>) could not be opened — the <code>data/</code> directory may have incorrect permissions. Rate limiting has been bypassed since <strong>' . $e($first_seen) . '</strong>. Fix the directory permissions to restore protection. The warning will clear automatically once storage is working again.</div>';
    }
    if (empty($ratelimits)) {
        echo '<p class="muted">No recent rate-limited IPs.</p>';
    } else {
        echo '<table class="ratelimit-table"><tr><th>IP</th><th>Count</th><th>Window start</th><th>Action</th></tr>';
        foreach ($ratelimits as $rip => $rec) {
            $ip_safe = $e($rip);
            $count = intval(isset($rec['count']) ? $rec['count'] : 0);
            $start = isset($rec['window_start']) ? date('Y-m-d H:i:s', intval($rec['window_start'])) : '-';
            echo '<tr>';
            echo '<td>' . $ip_safe . '</td>';
            echo '<td>' . $count . '</td>';
            echo '<td>' . $e($start) . '</td>';
            echo '<td>';
            echo '<form method="post" class="table-actions__form" data-confirm="Clear this rate limit entry?">';
            echo csrf_field();
            echo '<input type="hidden" name="action" value="clear_ratelimit_ip">';
            echo '<input type="hidden" name="tab" value="backups">';
            echo '<input type="hidden" name="ip" value="' . $ip_safe . '">';
            echo '<button class="btn" type="submit">Clear</button>';
            echo '</form>';
            echo '</td>';
            echo '</tr>';
        }
        echo '</table>';
        echo '<div class="mt-8">';
        echo '<form method="post" data-confirm="Clear all rate limit entries?">';
        echo csrf_field();
        echo '<input type="hidden" name="action" value="clear_ratelimit">';
        echo '<input type="hidden" name="tab" value="backups">';
        echo '<button class="btn danger" type="submit">Clear all</button>';
        echo '</form>';
        echo '</div>';
    }
    echo '</div>';
    echo '</div>';
} else {
    echo '<div class="section-grid">';
    if (!$selected) {
        echo '<div class="card">';
        echo '<h2 class="mt-0">Lists</h2>';
        if (!$lists) {
            echo '<p class="muted">No lists yet.</p>';
        } else {
            foreach ($lists as $list) {
                $list_slug = $e($list['slug']);
                $list_name = $e($list['name']);
                $list_desc = isset($list['description']) ? trim($list['description']) : '';
                echo '<div class="list-item">';
                echo '<div class="list-item-main">';
                echo '<a class="list-link" href="' . $tab_url('lists', array('list' => $list['slug'])) . '">&#9881; ' . $list_name . '</a>';
                echo '<div class="muted">' . $list_slug . '</div>';
                if ($list_desc !== '') {
                    echo '<div class="list-description">' . $e($list_desc) . '</div>';
                }
                echo '<div class="list-stats">' . intval(isset($list['_message_count']) ? $list['_message_count'] : 0) . ' messages · ' . intval(isset($list['_active_subscriber_count']) ? $list['_active_subscriber_count'] : 0) . ' active</div>';
                echo '</div>';
                echo '<div class="list-item-actions">';
                echo '<a class="btn secondary small-btn" href="' . $tab_url('subscribers', array('subscribers_list' => $list['slug'])) . '">View subscribers</a>';
                echo '<a class="btn secondary small-btn" href="' . $tab_url('lists', array('list' => $list['slug'])) . '">Setup</a>';
                echo '</div>';
                echo '</div>';
            }
        }
        echo '</div>';

        echo '<div class="card">';
        echo '<h2 class="mt-0">Create list</h2>';
        echo '<form method="post">';
        echo csrf_field();
        echo '<input type="hidden" name="action" value="create_list">';
        echo '<input type="hidden" name="tab" value="lists">';
        echo '<label>Name</label><input type="text" name="name" value="' . $e($create_name) . '" required placeholder="My list">';
        echo '<label class="mt-10">Slug (optional)</label><input type="text" name="slug" value="' . $e($create_slug) . '" placeholder="my-list">';
        echo '<label class="mt-10">Description</label><textarea name="description" placeholder="A short description of this list">' . $e($create_description) . '</textarea>';
        echo '<label class="mt-10">Thank you URL (optional)</label><input type="url" name="thank_you_url" value="' . $e($create_thank_you_url) . '" placeholder="https://example.com/thanks">';
        echo '<div class="mt-12"><button class="btn" type="submit">Create list</button></div>';
        echo '</form>';
        echo '</div>';
    } else {
        echo '<div class="card">';
        $slug_safe = $e($selected['slug']);
        $name_safe = $e($selected['name']);
        $description_safe = $e(isset($selected['description']) ? $selected['description'] : '');
        $from_name = $e(isset($selected['settings']['from_name']) ? $selected['settings']['from_name'] : '');
        $from_email = $e(isset($selected['settings']['from_email']) ? $selected['settings']['from_email'] : '');
        $thank_you = $e(isset($selected['settings']['thank_you_url']) ? $selected['settings']['thank_you_url'] : '');
        $form_url = $e(app_base_url() . '/index.php?list=' . rawurlencode($selected['slug']));
        $unsubscribe_example = $e(unsubscribe_url($selected['slug'], 'you@example.com'));

        echo '<div class="card-head">';
        echo '<div>';
        echo '<h2 class="mt-0">List: ' . $name_safe . '</h2>';
        echo '<div class="muted">Slug: <span class="pill">' . $slug_safe . '</span></div>';
        if ($description_safe !== '') {
            echo '<p class="list-description mt-10">' . $description_safe . '</p>';
        }
        echo '</div>';
        echo '<a class="btn secondary btn-back" href="' . $tab_url('lists') . '">Back to lists</a>';
        echo '</div>';

        echo '<h3>Settings</h3>';
        echo '<form method="post" class="settings-form">';
        echo csrf_field();
        echo '<input type="hidden" name="action" value="update_settings">';
        echo '<input type="hidden" name="tab" value="lists">';
        echo '<input type="hidden" name="list" value="' . $slug_safe . '">';
        echo '<label>Display name</label><input type="text" name="name" value="' . $name_safe . '">';
        echo '<label class="mt-10">Description</label><textarea name="description" placeholder="A short description of this list">' . $description_safe . '</textarea>';
        echo '<div class="split mt-10"><div><label>From name</label><input type="text" name="from_name" value="' . $from_name . '"></div><div><label>From email</label><input type="email" name="from_email" value="' . $from_email . '"></div></div>';
        echo '<label class="mt-10">Thank you URL</label><input type="url" name="thank_you_url" value="' . $thank_you . '" placeholder="Optional redirect after signup">';
        echo '<div class="public-toggle-wrap mt-10">';
        echo '<span class="public-toggle-text bold">Show this list on the public home page.<br></span>';
        echo '<label class="switch public-switch">';
        echo '<input type="checkbox" name="public" value="1"' . (!empty($selected['public']) ? ' checked' : '') . '>';
        echo '<span class="switch__slider switch__round"></span>';
        echo '</label>';
        echo '</div>';
        echo '<div class="mt-12"><button class="btn" type="submit">Save settings</button></div>';
        echo '</form>';

        echo '<div class="mini-info-grid">';
echo '<div class="mini-info"><div class="muted">Public form URL</div><input type="text" readonly class="copyable" value="' . $form_url . '" title="Click to copy public form URL" aria-label="Public form URL"></div>';
        echo '</div>';

        echo '<h3 class="mt-18">Embed form</h3>';
        echo '<textarea id="embed_code" readonly title="Embed form HTML" aria-label="Embed form HTML">' .
            $e('<link rel="stylesheet" href="https://javiernegron.github.io/autoresponder.vip/css/forms.css" integrity="sha384-rRyicc/AhdCZb7NnBlUvgze80hvmmLM9e8IuF12PgYsQvXPwRPyd23HAeisFZTTm" crossorigin="anonymous">' . '<form method="post" class="subscribe-form" action="' . app_base_url() . '/subscribe.php"><input type="hidden" name="list" value="' . $selected['slug'] . '"><input type="hidden" name="form_token" value="' . public_form_token($selected['slug']) . '"><div class="subscribe-form__hidden"><input type="text" name="website" tabindex="-1" autocomplete="off"></div><div class="subscribe-form__group"><input class="subscribe-form__input" type="text" name="name" placeholder="Name"></div><div class="subscribe-form__group"><input class="subscribe-form__input" type="email" name="email" placeholder="Email"></div><button class="subscribe-form__button" type="submit">Subscribe</button></form>') .
            '</textarea>';
        echo '<div class="mt-6"><button type="button" class="btn secondary" data-copy-target="#embed_code">Copy embed HTML</button></div>';
        echo '<p class="muted">Unsubscribe link example: <code>' . $unsubscribe_example . '</code></p>';
        echo '<p class="muted"><small>The embed form includes a <code>form_token</code> derived from your <code>unsubscribe_secret</code>. If you ever rotate that secret, regenerate the embed code from this page — existing forms on external pages will stop accepting subscriptions until updated.</small></p>';

        // echo '<div><p>Testing HTML code</p></div>';

                echo '<div class="row mt-12">';
        echo '<form method="post">';
        echo csrf_field();
        echo '<input type="hidden" name="action" value="download_csv">';
        echo '<input type="hidden" name="tab" value="lists">';
        echo '<input type="hidden" name="list" value="' . $slug_safe . '">';
        echo '<button class="btn secondary" type="submit">Export subscribers CSV</button>';
        echo '</form>';
        echo '<form method="post" data-confirm="Delete this list and all its data?">';
        echo csrf_field();
        echo '<input type="hidden" name="action" value="delete_list">';
        echo '<input type="hidden" name="tab" value="lists">';
        echo '<input type="hidden" name="list" value="' . $slug_safe . '">';
        echo '<button class="btn danger" type="submit">Delete list</button>';
        echo '</form>';
        echo '</div>';

        echo '</div>';



        
        echo '<div class="card">';
        echo '<h2 class="mt-0">' . ($message_id !== '' ? 'Edit message' : 'Add sequential message') . '</h2>';
        echo '<form method="post" class="settings-form">';
        echo csrf_field();
        echo '<input type="hidden" name="action" value="save_message">';
        echo '<input type="hidden" name="tab" value="lists">';
        echo '<input type="hidden" name="list" value="' . $slug_safe . '">';
        echo '<input type="hidden" name="message_id" value="' . $e($message_id) . '" id="msg-id-field">';
        echo '<label>Subject</label><input type="text" name="subject" placeholder="Welcome to the list" value="' . $e($message_subject) . '" id="msg-subject-field">';
        echo '<label class="mt-10">Delay days before this message</label><input type="number" min="0" step="1" name="delay_days" value="' . intval($message_delay_days) . '" placeholder="0" id="msg-delay-field">';
        echo '<label class="mt-10">Body</label><textarea name="body" placeholder="Hello {{NAME}}, ..." id="msg-body-field">' . $e($message_body) . '</textarea>';
        echo '<div class="muted mt-6">Available merge fields. Click any field to copy it.</div>';
        echo '<div class="token-grid">';
        $tokens = array('{{NAME}}','{{FIRSTNAME}}','{{EMAIL}}','{{LIST}}','{{UNSUBSCRIBE_URL}}','{{SITE_URL}}');
        foreach ($tokens as $t) {
            $token = $e($t);
            $title = $e('Click to copy ' . $t);
            echo '<input type="text" readonly class="token" value="' . $token . '" title="' . $title . '" aria-label="' . $title . '">';
        }
        echo '</div>';
        echo '<div class="mt-12 row">';
        echo '<button class="btn" type="submit" id="msg-submit-btn">' . ($message_id !== '' ? 'Save changes' : 'Add message') . '</button>';
        if ($message_id !== '') {
            echo '<button type="button" class="btn secondary" data-reset-msg-form="1">Cancel</button>';
        }
        echo '</div>';
        echo '</form>';

        if (empty($selected['messages'])) {
            echo '<p class="muted mt-16">No messages yet.</p>';
        } else {
            echo '<h2>Message sequence</h2>';
            echo '<table class="mt-16 messages-table"><tr><th>#</th><th>Subject</th><th>Delay</th><th>Action</th></tr>';
            foreach ($selected['messages'] as $i => $message) {
                $mid = $e($message['id']);
                $msubject = $e(isset($message['subject']) ? $message['subject'] : '');
                $mbody = $e(isset($message['body']) ? $message['body'] : '');
                $mdelay = intval(isset($message['delay_days']) ? $message['delay_days'] : 0);
                echo '<tr>';
                echo '<td>' . intval($i + 1) . '</td>';
                echo '<td><strong>' . $msubject . '</strong><br><span class="muted">' . nl2br($e(isset($message['body']) ? $message['body'] : '')) . '</span></td>';
                echo '<td>' . $mdelay . '</td>';
                echo '<td>';
                echo '<div class="message-sequence__actions">';
                $message_payload = json_encode(array(
                    'id' => $message['id'],
                    'subject' => isset($message['subject']) ? $message['subject'] : '',
                    'body' => isset($message['body']) ? $message['body'] : '',
                    'delay_days' => $mdelay,
                ), JSON_UNESCAPED_UNICODE);
                echo '<button type="button" class="btn secondary" data-message="' . htmlspecialchars($message_payload, ENT_QUOTES, 'UTF-8') . '">Edit</button>';
                echo '<form method="post" data-confirm="Delete this message?">';
                echo csrf_field();
                echo '<input type="hidden" name="action" value="delete_message">';
                echo '<input type="hidden" name="tab" value="lists">';
                echo '<input type="hidden" name="list" value="' . $slug_safe . '">';
                echo '<input type="hidden" name="message_id" value="' . $mid . '">';
                echo '<button class="btn danger" type="submit">Delete</button>';
                echo '</form>';
                echo '</div>';
                echo '</td>';
                echo '</tr>';
            }
            echo '</table>';
        }

        echo '</div>';
    }
    echo '</div>';
}

echo '<script src="' . htmlspecialchars(app_base_url(), ENT_QUOTES, 'UTF-8') . '/admin.js"></script>';

    render_footer();

} // end else (admin authenticated)

