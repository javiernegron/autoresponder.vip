/**
 * admin.js — Autoresponder.vip administration panel scripts.
 *
 * Loaded via <script src="admin.js"> from render_header() when the admin is
 * authenticated. Externalising this file removes the need for 'unsafe-inline'
 * in the Content-Security-Policy script-src directive (audit T-1).
 *
 * All functions that were previously referenced by inline event handlers
 * (onclick, onsubmit, onchange) are exposed on the window object so they
 * remain reachable from HTML attributes without 'unsafe-inline' in script-src.
 * The event handlers themselves still use the attribute syntax for now —
 * migrating them to addEventListener calls would complete the CSP hardening
 * but is out of scope for this change.
 */
(function () {
  'use strict';

  // ---------------------------------------------------------------------------
  // Toast notification
  // ---------------------------------------------------------------------------
  function toast(message) {
    var node = document.createElement("div");
    node.className = "toast";
    node.textContent = message;
    document.body.appendChild(node);
    requestAnimationFrame(function () {
      node.classList.add("show");
    });
    setTimeout(function () {
      node.classList.remove("show");
      setTimeout(function () {
        if (node.parentNode) {
          node.parentNode.removeChild(node);
        }
      }, 220);
    }, 2200);
  }

  // ---------------------------------------------------------------------------
  // Confirm dialog
  // ---------------------------------------------------------------------------
  var confirmState = {
    node: null,
    resolve: null
  };

  function ensureConfirmModal() {
    if (confirmState.node) return confirmState.node;
    var overlay = document.createElement("div");
    overlay.className = "confirm-overlay";
    overlay.innerHTML = "<div class=\"confirm-modal\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"confirm-title\"><h3 id=\"confirm-title\">Please confirm</h3><p class=\"confirm-message\"></p><div class=\"confirm-actions\"><button type=\"button\" class=\"btn secondary\" data-confirm-cancel>Cancel</button><button type=\"button\" class=\"btn danger\" data-confirm-ok>Continue</button></div></div>";
    document.body.appendChild(overlay);
    overlay.addEventListener("click", function (event) {
      if (event.target === overlay) {
        closeConfirm(false);
      }
    });
    overlay.querySelector("[data-confirm-cancel]").addEventListener("click", function () {
      closeConfirm(false);
    });
    overlay.querySelector("[data-confirm-ok]").addEventListener("click", function () {
      closeConfirm(true);
    });
    document.addEventListener("keydown", function (event) {
      if (confirmState.node && event.key === "Escape") {
        closeConfirm(false);
      }
    });
    confirmState.node = overlay;
    return overlay;
  }

  function closeConfirm(confirmed) {
    if (!confirmState.node) return;
    confirmState.node.classList.remove("show");
    var resolver = confirmState.resolve;
    confirmState.resolve = null;
    setTimeout(function () {
      if (confirmState.node) {
        confirmState.node.remove();
        confirmState.node = null;
      }
    }, 160);
    if (resolver) {
      resolver(confirmed);
    }
  }

  function confirmDialog(message) {
    var overlay = ensureConfirmModal();
    overlay.querySelector(".confirm-message").textContent = message || "Are you sure?";
    overlay.classList.add("show");
    return new Promise(function (resolve) {
      confirmState.resolve = resolve;
    });
  }

  document.addEventListener("submit", function (event) {
    var form = event.target;
    if (!form || !form.matches || !form.matches("form[data-confirm]")) {
      return;
    }
    event.preventDefault();
    var message = form.getAttribute("data-confirm") || "Are you sure?";
    confirmDialog(message).then(function (confirmed) {
      if (confirmed) {
        form.submit();
      }
    });
  });

  // ---------------------------------------------------------------------------
  // Copy-to-clipboard helper (exposed globally for onclick= attributes)
  // ---------------------------------------------------------------------------
  window.copyToken = function (el) {
    var value = el.value || "";
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(value).then(function () {
        toast("Copied to clipboard");
      });
      return;
    }
    el.select();
    try {
      document.execCommand("copy");
      toast("Copied to clipboard");
    } catch (err) {}
  };

  // ---------------------------------------------------------------------------
  // Global send form validation (exposed globally for onsubmit= attribute)
  // ---------------------------------------------------------------------------
  window.validateGlobalSend = function (event) {
    var allBox = document.querySelector("[form=\"global-send-form\"][data-target-all]");
    var itemBoxes = document.querySelectorAll("[form=\"global-send-form\"][data-target-item]");
    var selected = [];
    if (allBox && allBox.checked) {
      selected.push("all");
    } else {
      for (var i = 0; i < itemBoxes.length; i++) {
        if (itemBoxes[i].checked) {
          selected.push(itemBoxes[i].value);
        }
      }
    }
    if (!selected.length) {
      event.preventDefault();
      toast("Please select one or more lists before sending.");
      return false;
    }
    return true;
  };

  // ---------------------------------------------------------------------------
  // Target-list checkbox state sync (All list ↔ individual items)
  // ---------------------------------------------------------------------------
  function syncTargetListState() {
    var form = document.getElementById("global-send-form");
    if (!form) return;
    var allBox = document.querySelector("[form=\"global-send-form\"][data-target-all]");
    var itemBoxes = document.querySelectorAll("[form=\"global-send-form\"][data-target-item]");
    function refresh() {
      if (allBox && allBox.checked) {
        for (var i = 0; i < itemBoxes.length; i++) {
          itemBoxes[i].checked = false;
          itemBoxes[i].disabled = true;
        }
      } else {
        for (var j = 0; j < itemBoxes.length; j++) {
          itemBoxes[j].disabled = false;
        }
      }
    }
    if (allBox) {
      allBox.addEventListener("change", refresh);
    }
    for (var i = 0; i < itemBoxes.length; i++) {
      itemBoxes[i].addEventListener("change", function () {
        if (this.checked && allBox) {
          allBox.checked = false;
        }
        refresh();
      });
    }
    refresh();
  }

  function attachCopyHandlers() {
    var copyTargets = document.querySelectorAll("input.token, input.copyable, button[data-copy-target]");
    for (var i = 0; i < copyTargets.length; i++) {
      (function (node) {
        node.addEventListener("click", function () {
          var target = node.getAttribute("data-copy-target");
          if (target) {
            var targetNode = document.querySelector(target);
            if (targetNode) {
              copyToken(targetNode);
            }
            return;
          }
          if (node.matches("input")) {
            copyToken(node);
          }
        });
      })(copyTargets[i]);
    }
  }

  function attachGlobalSendValidation() {
    var form = document.getElementById("global-send-form");
    if (!form) return;
    form.addEventListener("submit", function (event) {
      if (!validateGlobalSend(event)) {
        event.preventDefault();
      }
    });
  }

  function attachMessageEditButtons() {
    var buttons = document.querySelectorAll("button[data-message]");
    for (var i = 0; i < buttons.length; i++) {
      (function (button) {
        button.addEventListener("click", function () {
          try {
            var payload = JSON.parse(button.dataset.message);
            editMsg(payload);
          } catch (err) {
            toast("Unable to load message for editing.");
          }
        });
      })(buttons[i]);
    }
  }

  function attachResetMessageButtons() {
    var buttons = document.querySelectorAll("button[data-reset-msg-form]");
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].addEventListener("click", resetMsgForm);
    }
  }

  function attachAutoSubmitSelects() {
    var selects = document.querySelectorAll("select[data-auto-submit]");
    for (var i = 0; i < selects.length; i++) {
      selects[i].addEventListener("change", function () {
        if (this.form) {
          this.form.submit();
        }
      });
    }
  }

  function initAdminPanel() {
    syncTargetListState();
    attachCopyHandlers();
    attachGlobalSendValidation();
    attachMessageEditButtons();
    attachResetMessageButtons();
    attachAutoSubmitSelects();
  }

  initAdminPanel();

  // ---------------------------------------------------------------------------
  // Sequential message form — edit / reset (exposed globally for onclick=)
  // ---------------------------------------------------------------------------
  window.editMsg = function (msg) {
    document.getElementById("msg-id-field").value = msg.id;
    document.getElementById("msg-subject-field").value = msg.subject;
    document.getElementById("msg-body-field").value = msg.body;
    document.getElementById("msg-delay-field").value = msg.delay_days;
    document.getElementById("msg-submit-btn").textContent = "Save changes";
    document.getElementById("msg-subject-field").scrollIntoView({behavior: "smooth", block: "center"});
  };

  window.resetMsgForm = function () {
    document.getElementById("msg-id-field").value = "";
    document.getElementById("msg-subject-field").value = "";
    document.getElementById("msg-body-field").value = "";
    document.getElementById("msg-delay-field").value = "0";
    document.getElementById("msg-submit-btn").textContent = "Add message";
  };

})();
