<?php
require __DIR__ . '/lib.php';
app_bootstrap();
config_require_secrets_or_exit('plain');

$cfg = app_cfg();
$is_cli = (php_sapi_name() === 'cli' || PHP_SAPI === 'cli');

$authorized = false;
$is_public_trigger = false;

if ($is_cli) {
    $authorized = true;
} else {
    $trigger = isset($_GET['public_trigger']) ? $_GET['public_trigger'] : '';
    if ($trigger !== '' && isset($cfg['public_trigger_key']) && secure_equals($trigger, $cfg['public_trigger_key'])) {
        $authorized = true;
        $is_public_trigger = true;
    }
}

if (!$authorized) {
    if (!headers_sent()) {
        header('HTTP/1.1 403 Forbidden');
        header('Content-Type: text/plain; charset=UTF-8');
    }
    echo "Forbidden\n";
    exit;
}

// Acquire the exclusive process lock FIRST — before reading cron_status.json,
// before processing the queue, and before running the delivery cycle.
//
// Previous order: check status → acquire lock → write status → process.
// That left a race window where two concurrent requests could both pass the
// interval check (both read the same stale last_run timestamp), then race for
// the lock. The second would be rejected by LOCK_NB, but only after both had
// already decided to run. More critically, mail_queue_process() was called
// after the lock, so two simultaneous CLI + web-trigger executions could both
// enter mail_queue_process() and produce duplicate sends.
//
// Correct order: acquire lock → check status → write status → process.
// Now the interval check and all processing happen inside the same lock window,
// making the entire cron execution atomic with respect to other instances.
$lock_file = data_dir() . '/cron.lock';
$lock_fp = @fopen($lock_file, 'c');
if ($lock_fp === false || !flock($lock_fp, LOCK_EX | LOCK_NB)) {
    if ($lock_fp !== false) {
        fclose($lock_fp);
    }
    if (!headers_sent()) {
        header('HTTP/1.1 204 No Content');
    }
    app_log('warn', 'cron.php skipped: another instance is already running');
    exit;
}

// Inside the lock: check the public trigger interval and update the timestamp.
// Because we now hold the exclusive lock, no two processes can pass this check
// concurrently — the second will have been rejected by LOCK_NB above.
$status_file = data_dir() . '/cron_status.json';
if ($is_public_trigger) {
    $last_run = 0;
    if (file_exists($status_file)) {
        $status_data = json_decode(@file_get_contents($status_file), true);
        if (is_array($status_data) && isset($status_data['last_run'])) {
            $last_run = intval($status_data['last_run']);
        }
    }

    $interval_minutes = isset($cfg['cron_public_interval_minutes']) ? intval($cfg['cron_public_interval_minutes']) : 5;
    $interval_seconds = $interval_minutes * 60;

    if (time() - $last_run < $interval_seconds) {
        flock($lock_fp, LOCK_UN);
        fclose($lock_fp);
        if (!headers_sent()) {
            header('HTTP/1.1 204 No Content');
        }
        exit;
    }

    // Stamp the run time before processing so that even if processing is slow,
    // the next request sees an up-to-date timestamp and does not slip through.
    @file_put_contents($status_file, json_encode(array('last_run' => time())), LOCK_EX);
}

$queue_result = mail_queue_process();
$result = run_delivery_cycle();

flock($lock_fp, LOCK_UN);
fclose($lock_fp);

// Web trigger: return 204 No Content — no system information is exposed to
// the external cron service. The trigger key proves authorization; the
// response content adds no value and leaks activity details unnecessarily.
// Detailed output is reserved for CLI execution where it aids diagnostics.
if ($is_public_trigger) {
    if (!headers_sent()) {
        header('HTTP/1.1 204 No Content');
    }
    exit;
}

// CLI output — useful for manual runs, cPanel cron job logs, etc.
if (!headers_sent()) {
    header('Content-Type: text/plain; charset=UTF-8');
}
echo "Delivered: " . intval($result['sent']) . "\n";
echo "Queue sent: " . intval($queue_result['sent']) . "\n";
echo "Queue remaining: " . intval($queue_result['queued']) . "\n";
if (!empty($queue_result['quota_exhausted'])) {
    echo "Queue quota exhausted: yes\n";
}
foreach ($result['log'] as $line) {
    echo $line . "\n";
}
