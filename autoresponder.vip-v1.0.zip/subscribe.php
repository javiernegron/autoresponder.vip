<?php
require __DIR__ . '/lib.php';
app_bootstrap();
redirect_to_https_if_needed();
config_require_secrets_or_exit_public();
if (session_status() !== PHP_SESSION_ACTIVE) {
    secure_session_start();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$slug = isset($_POST['list']) ? $_POST['list'] : '';
$name = sanitize_short_text(isset($_POST['name']) ? $_POST['name'] : '');
// Normalize email to lowercase immediately — all validation, storage, and
// token generation must operate on the canonical form to prevent duplicates.
$email = normalize_email(isset($_POST['email']) ? $_POST['email'] : '');
$form_token = isset($_POST['form_token']) ? $_POST['form_token'] : '';
$honeypot = isset($_POST['website']) ? trim($_POST['website']) : '';

// Rate limit by IP to avoid automated abuse
$client_ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
if (!rate_limit_check_and_increment($client_ip)) {
    app_log('warn', 'Subscription rate-limited from IP ' . $client_ip . ' list=' . $slug . ' email=' . $email);
    render_header('Subscription error');
    echo '<div class="warn">Too many subscription attempts from your IP. Please try again later.</div>';
    render_footer();
    exit;
}

if (!valid_slug($slug) || !is_valid_email($email) || $honeypot !== '' || !public_form_token_valid($slug, $form_token)) {
    app_log('warn', 'Invalid subscription attempt from IP ' . $client_ip . ' list=' . $slug . ' email=' . $email);
    render_header('Subscription error');
    echo '<div class="warn">Please provide a valid list and email address.</div>';
    render_footer();
    exit;
}

$list = load_list($slug);
if (!$list) {
    app_log('warn', 'Subscription to missing list from IP ' . $client_ip . ' list=' . $slug . ' email=' . $email);
    render_header('Subscription error');
    echo '<div class="warn">List not found.</div>';
    render_footer();
    exit;
}

// Capture immutable display values before entering the lock.
$list_name = $list['name'];
$redirect = isset($list['settings']['thank_you_url']) ? trim($list['settings']['thank_you_url']) : '';

// Perform the read-modify-write (and any first-message dispatch) under the
// exclusive list lock so concurrent unsubscribe/cron/admin edits cannot lose
// this subscriber or be overwritten by it.
$now = time();
$saved = with_list_lock($slug, function () use ($slug, $email, $name, $now) {
    $list = load_list($slug);
    if (!$list) {
        return false;
    }
    // Queue the subscriber for immediate dispatch on the next cron run.
    // Setting next_send_at = $now (current time) ensures run_delivery_cycle()
    // will pick it up on the very next execution without inline sending,
    // which eliminates the email-bombing risk on the public subscribe endpoint.
    $index = list_subscriber_index($list, $email);
    if ($index >= 0) {
        $subscriber = $list['subscribers'][$index];
        $subscriber = ensure_subscriber_defaults($subscriber);
        $subscriber['name'] = $name !== '' ? $name : $subscriber['name'];
        $subscriber['status'] = 'active';
        $subscriber['next_message_index'] = 0;
        $subscriber['next_send_at'] = $now;
        $subscriber['fail_count'] = 0;
        $subscriber['last_error'] = '';
        $subscriber['bounce_reason'] = '';
        $subscriber['updated_at'] = $now;
        $list['subscribers'][$index] = $subscriber;
    } else {
        $subscriber = ensure_subscriber_defaults(array(
            'name' => $name,
            'email' => $email,
            'status' => 'active',
            'next_message_index' => 0,
            'next_send_at' => $now,
            'created_at' => $now,
            'updated_at' => $now,
        ));
        $list['subscribers'][] = $subscriber;
        $index = count($list['subscribers']) - 1;
    }

    $list['subscribers'][$index]['token'] = unsubscribe_token($email);
    return save_list($list);
});

if ($saved !== true) {
    app_log('warn', 'Subscription could not be saved list=' . $slug . ' email=' . $email . ' ip=' . $client_ip);
    render_header('Subscription error');
    echo '<div class="warn">We could not save your subscription right now. Please try again later.</div>';
    render_footer();
    exit;
}

app_log('info', 'Subscription saved list=' . $slug . ' email=' . $email . ' ip=' . $client_ip);

// Reject any URL scheme other than http:// or https:// to prevent Open Redirect
// via malicious schemes (e.g. javascript:, data:) stored in the list settings,
// and validate that the host matches the local environment or base_url.
if ($redirect !== '' && preg_match('/^https?:\/\//i', $redirect) && is_safe_redirect_url($redirect)) {
    header('Location: ' . $redirect);
    exit;
}

render_header('Thank you');
echo '<div class="card">';
echo '<h2 class="mt-0">Thank you</h2>';
echo '<p>Your subscription has been saved for <strong>' . htmlspecialchars($list_name, ENT_QUOTES, 'UTF-8') . '</strong>.</p>';
echo '<p class="muted">A first message will be sent if the list has one configured.</p>';
echo '<p><a class="btn" href="index.php?list=' . rawurlencode($slug) . '">Back to form</a></p>';
echo '</div>';
render_footer();
