<?php
require __DIR__ . '/lib.php';
app_bootstrap();
config_require_secrets_or_exit_public();

$slug = isset($_GET['list']) ? $_GET['list'] : '';
// Normalize email to lowercase immediately so the HMAC token validation and
// list lookup are consistent regardless of the casing in the unsubscribe URL.
$email = normalize_email(isset($_GET['email']) ? $_GET['email'] : '');
$token = isset($_GET['token']) ? $_GET['token'] : '';

if (!valid_slug($slug) || !is_valid_email($email) || !secure_equals(unsubscribe_token($email), $token)) {
    app_log('warn', 'Invalid unsubscribe attempt list=' . $slug . ' email=' . $email . ' token=' . substr($token, 0, 8));
    render_header('Unsubscribe');
    echo '<div class="warn">Invalid unsubscribe link.</div>';
    render_footer();
    exit;
}

$list = load_list($slug);
if (!$list) {
    render_header('Unsubscribe');
    echo '<div class="warn">List not found.</div>';
    render_footer();
    exit;
}

// Update the subscriber status under the list lock so a concurrent
// subscribe or cron delivery cannot race against the write.
with_list_lock($slug, function () use ($slug, $email) {
    $list = load_list($slug);
    if (!$list) {
        return;
    }
    $index = list_subscriber_index($list, $email);
    if ($index >= 0) {
        $list['subscribers'][$index] = ensure_subscriber_defaults($list['subscribers'][$index]);
        $list['subscribers'][$index]['status'] = 'unsubscribed';
        $list['subscribers'][$index]['updated_at'] = time();
        save_list($list);
    }
});
app_log('info', 'Unsubscribed email=' . $email . ' list=' . $slug);

render_header('Unsubscribed');
echo '<div class="card"><h2 class="mt-0">You are unsubscribed</h2><p>' . htmlspecialchars($email, ENT_QUOTES, 'UTF-8') . ' has been removed from the active list.</p></div>';
render_footer();
