<?php

/**
 * Get application configuration.
 *
 * @return array
 */
function app_cfg($reload = false)
{
    static $cfg = null;
    if ($reload) {
        $cfg = null;
    }
    if ($cfg === null) {
        $cfg = include __DIR__ . '/config.php';
    }
    return $cfg;
}

/**
 * Placeholder value used in config.example.php for secrets not yet configured.
 *
 * @return string
 */
function config_placeholder_marker()
{
    return 'CHANGE_ME';
}

/**
 * Return true when a config value is empty or still a default placeholder.
 * Recognizes the base marker ('CHANGE_ME') as well as descriptive placeholders
 * such as 'CHANGE_ME_SECRET_TOKEN' or 'CHANGE_ME_PUBLIC_TRIGGER' used in
 * config.example.php, so the script never runs with an unconfigured secret.
 *
 * @param mixed $value
 * @return bool
 */
function config_is_placeholder($value)
{
    $value = trim((string) $value);
    if ($value === '') {
        return true;
    }
    if ($value === config_placeholder_marker()) {
        return true;
    }
    return strpos($value, config_placeholder_marker() . '_') === 0;
}

/**
 * Return config secret keys that still use placeholder values.
 *
 * @param array|null $cfg
 * @return array<int,string>
 */
function config_unconfigured_secret_keys($cfg = null)
{
    if ($cfg === null) {
        $cfg = app_cfg();
    }
    $missing = array();

    $stored_password = isset($cfg['admin_password']) ? (string) $cfg['admin_password'] : '';
    if ($stored_password === '' || (!admin_password_is_hashed($stored_password) && config_is_placeholder($stored_password))) {
        $missing[] = 'admin_password';
    }
    if (config_is_placeholder(isset($cfg['unsubscribe_secret']) ? $cfg['unsubscribe_secret'] : '')) {
        $missing[] = 'unsubscribe_secret';
    }
    if (config_is_placeholder(isset($cfg['public_trigger_key']) ? $cfg['public_trigger_key'] : '')) {
        $missing[] = 'public_trigger_key';
    }
    if (!empty($cfg['smtp_enabled'])) {
        if (config_is_placeholder(isset($cfg['smtp_username']) ? $cfg['smtp_username'] : '')) {
            $missing[] = 'smtp_username';
        }
        if (config_is_placeholder(isset($cfg['smtp_password']) ? $cfg['smtp_password'] : '')) {
            $missing[] = 'smtp_password';
        }
    }

    return $missing;
}

/**
 * Stop execution when essential secrets in config.php are still placeholders.
 *
 * @param string $format Response format: html or plain.
 * @return void
 */
function config_require_secrets_or_exit($format = 'html')
{
    $missing = config_unconfigured_secret_keys();
    if (empty($missing)) {
        return;
    }

    $keys = implode(', ', $missing);
    $message = 'Please configure your secrets in config.php before using this script. '
        . 'Replace every CHANGE_ME placeholder for: ' . $keys . '. '
        . 'If you do not have config.php yet, copy config.example.php to config.php and fill in your values.';

    if ($format === 'plain') {
        if (!headers_sent()) {
            header('Content-Type: text/plain; charset=UTF-8');
            header('HTTP/1.1 503 Service Unavailable');
        }
        die("Configuration required\n\n" . $message . "\n");
    }

    if (!headers_sent()) {
        header('Content-Type: text/html; charset=UTF-8');
        header('HTTP/1.1 503 Service Unavailable');
        emit_security_headers();
    }
    $safe = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
    $keys_safe = htmlspecialchars($keys, ENT_QUOTES, 'UTF-8');
    die('<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">'
        . '<title>Configuration required</title>'
        . '<link rel="stylesheet" href="style.css"></head><body class="config-required">'
        . '<div class="config-required__container">'
        . '<h1 class="config-required__title">Configuration required</h1>'
        . '<div class="config-required__box"><p>' . $safe . '</p>'
        . '<p><strong>Missing or placeholder keys:</strong> ' . $keys_safe . '</p></div>'
        . '</div></body></html>');
}

/**
 * Stop execution with a clean maintenance page if placeholders are still present.
 * This is for public-facing files (index.php, subscribe.php, unsubscribe.php).
 *
 * @return void
 */
function config_require_secrets_or_exit_public()
{
    $missing = config_unconfigured_secret_keys();
    if (empty($missing)) {
        return;
    }

    if (!headers_sent()) {
        header('Content-Type: text/html; charset=UTF-8');
        header('HTTP/1.1 503 Service Unavailable');
        emit_security_headers();
    }

    die('<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website under maintenance / Sitio en mantenimiento</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="maintenance-page">
    <div class="maintenance-page__container">
        <div class="maintenance-page__card">
            <div class="maintenance-page__logo">Autoresponder<span class="maintenance-page__logo-accent">.vip</span></div>
            <h1 class="maintenance-page__title">Website under maintenance</h1>
            <p class="maintenance-page__text">This website is temporarily offline for technical maintenance or initial setup. Please check back soon.</p>
            <hr class="maintenance-page__rule">
            <h1 class="maintenance-page__title maintenance-page__title--secondary">Sitio en mantenimiento</h1>
            <p class="maintenance-page__text">Este sitio web se encuentra temporalmente fuera de servicio por mantenimiento técnico o configuración inicial. Por favor, vuelva a intentarlo más tarde.</p>
            <div class="maintenance-page__badge">Technical Maintenance / Mantenimiento Técnico</div>
        </div>
    </div>
</body>
</html>');
}

/**
 * Bootstrap application (timezone + storage).
 *
 * @return void
 */
function app_bootstrap()
{
    $cfg = app_cfg();
    if (!empty($cfg['time_zone'])) {
        @date_default_timezone_set($cfg['time_zone']);
    }
    ensure_storage();
    @ini_set('log_errors', '1');
    @ini_set('error_log', daily_log_path());
}

/**
 * Start a PHP session with hardened cookie security flags.
 *
 * Must be called instead of a bare session_start() in every entry point that
 * requires a session (admin.php, subscribe.php). Calling it when a session is
 * already active is a safe no-op.
 *
 * Security measures applied:
 *  - use_strict_mode: rejects session IDs not issued by this server, blocking
 *    session fixation attacks.
 *  - httponly: prevents JavaScript from reading the session cookie, mitigating
 *    XSS-based session hijacking.
 *  - secure: transmits the cookie only over HTTPS when the connection is
 *    detected as encrypted (avoids exposure over plain HTTP).
 *  - samesite=Lax: blocks cross-site request forgery via third-party navigation
 *    while still allowing the session cookie on top-level same-site navigations.
 *  - path: scoped to the installation subdirectory to isolate the session cookie
 *    from other applications hosted on the same domain.
 *
 * @return void
 */
function secure_session_start()
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return; // Already started — nothing to do.
    }

    // Prevent the server from accepting session IDs supplied by the client that
    // were not originally issued by this application (session fixation defence).
    @ini_set('session.use_strict_mode', '1');

    // Detect HTTPS: check the HTTPS server variable and the forwarded protocol
    // header used by common reverse proxies (nginx, Apache mod_proxy, etc.).
    $is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443)
        || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https');

    // Scope the session cookie to the installation subdirectory rather than
    // the whole domain ('/'). This prevents a vulnerable app elsewhere on the
    // same shared host from accessing this session cookie via an XSS attack.
    //
    // __DIR__ is a PHP compile-time constant — the absolute filesystem path of
    // lib.php — which is not influenced by client-supplied HTTP headers.
    // We compare it to DOCUMENT_ROOT to derive the URL path segment.
    // Example: DOCUMENT_ROOT=/var/www/html, __DIR__=/var/www/html/autoresponder
    //          → cookie path = /autoresponder
    //
    // SCRIPT_NAME (the alternative suggested in some audits) is a CGI/SAPI
    // variable that can be spoofed via Host or PATH_INFO in some server
    // configurations; __DIR__ is immune to that class of manipulation.
    $doc_root    = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim($_SERVER['DOCUMENT_ROOT'], '/\\') : '';
    $install_dir = rtrim(__DIR__, '/\\');
    if ($doc_root !== '' && strpos($install_dir, $doc_root) === 0) {
        $cookie_path = str_replace('\\', '/', substr($install_dir, strlen($doc_root)));
        if ($cookie_path === '') {
            $cookie_path = '/';
        }
    } else {
        // Fallback: CLI context (cron), exotic server configs, or __DIR__ is
        // outside DOCUMENT_ROOT. Use '/' — no worse than the previous default.
        $cookie_path = '/';
    }

    session_set_cookie_params(array(
        'lifetime' => 0,             // Expire on browser close (not a persistent cookie).
        'path'     => $cookie_path,  // Scoped to the installation subdirectory.
        'domain'   => '',            // Current host — let PHP derive it automatically.
        'secure'   => $is_https,     // Only send over HTTPS when available.
        'httponly' => true,          // Block JavaScript access to the session cookie.
        'samesite' => 'Lax',         // Change to 'Strict' for maximum CSRF isolation.
    ));

    session_start();
}

/**
 * Redirect to HTTPS if the current request arrived over plain HTTP.
 *
 * This is a defence-in-depth measure: even if the server is configured to
 * serve over HTTPS only, an explicit 301 from PHP prevents session cookies
 * from being transmitted in the clear on the initial request.
 *
 * Detection order (matches secure_session_start() and app_base_url()):
 *   1. $_SERVER['HTTPS'] set and not 'off'  → already HTTPS, do nothing.
 *   2. SERVER_PORT === 443                  → already HTTPS, do nothing.
 *   3. HTTP_X_FORWARDED_PROTO === 'https'   → behind a reverse proxy, do nothing.
 *   4. Otherwise                            → redirect with 301.
 *
 * The redirect target is built from base_url (if configured) or from the
 * validated HTTP_HOST / SERVER_NAME (same validation as app_base_url()).
 * REQUEST_URI is included as-is; it is controlled by the server, not the
 * client, on most SAPI configurations, but is never used to build a new
 * host — only the path/query portion is reused.
 *
 * The function is a no-op in CLI context (no HTTP headers available).
 *
 * @return void
 */
function redirect_to_https_if_needed()
{
    // No HTTP context (CLI/cron) — nothing to redirect.
    if (php_sapi_name() === 'cli' || !isset($_SERVER['REQUEST_METHOD'])) {
        return;
    }

    // Already on HTTPS — nothing to do.
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        return;
    }
    if (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443) {
        return;
    }
    // Correctly check the forwarded protocol header used by reverse proxies.
    // Note: the comparison must be on the *value*, not the result of !empty().
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') {
        return;
    }

    // Build the HTTPS target. Prefer base_url from config if set, as it is
    // the canonical authoritative origin for this installation.
    $cfg = app_cfg();
    if (!empty($cfg['base_url'])) {
        $base = rtrim($cfg['base_url'], '/');
        // Replace the scheme with https regardless of what base_url says.
        $base = preg_replace('/^https?:\/\//i', 'https://', $base);
    } else {
        // Validate HTTP_HOST before using it in a Location header to prevent
        // Host-header injection (same pattern as app_base_url()).
        $host = '';
        if (!empty($_SERVER['HTTP_HOST'])) {
            $candidate = $_SERVER['HTTP_HOST'];
            if (preg_match('/^[a-zA-Z0-9\-\.\:\[\]]+$/', $candidate)) {
                $host = $candidate;
            }
        }
        if ($host === '' && !empty($_SERVER['SERVER_NAME'])) {
            $candidate = $_SERVER['SERVER_NAME'];
            if (preg_match('/^[a-zA-Z0-9\-\.\:\[\]]+$/', $candidate)) {
                $host = $candidate;
            }
        }
        if ($host === '') {
            // Cannot determine a safe host — skip the redirect rather than
            // issuing a header with an untrusted value.
            return;
        }
        $base = 'https://' . $host;
    }

    $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
    header('Location: ' . $base . $uri, true, 301);
    exit;
}

/**
 * Ensure data storage directories and index files exist.
 *
 * @return void
 */
function ensure_storage()
{
    // Static flag: skip all filesystem checks after the first successful run
    // within the same PHP process. On shared hosting with slow NFS or many
    // is_dir()/file_exists() calls per request, this saves several syscalls
    // on every page load after the first (audit T-4).
    static $done = false;
    if ($done) {
        return;
    }

    $cfg = app_cfg();
    $base = rtrim($cfg['data_dir'], '/\\');
    $htaccess = "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Deny from all\n</IfModule>\n";
    $forbidden_html = "<!DOCTYPE html><meta charset=\"utf-8\"><title>Forbidden</title>";

    if (!is_dir($base)) {
        @mkdir($base, 0755, true);
    }
    if (!is_dir($base . '/lists')) {
        @mkdir($base . '/lists', 0755, true);
    }
    if (!is_dir($base . '/locks')) {
        @mkdir($base . '/locks', 0755, true);
    }

    // Protect the data/ root directory itself — .htaccess blocks direct HTTP
    // access to admin_login.json, ratelimit.json, mail.log, and any other
    // sensitive runtime files stored here. This was previously missing; only
    // data/locks/ and logs/ had .htaccess protection (audit A-2 / A-4).
    if (!file_exists($base . '/.htaccess')) {
        @file_put_contents($base . '/.htaccess', $htaccess);
    }
    if (!file_exists($base . '/index.html')) {
        @file_put_contents($base . '/index.html', $forbidden_html);
    }
    if (!file_exists($base . '/lists/index.html')) {
        @file_put_contents($base . '/lists/index.html', $forbidden_html);
    }
    if (!file_exists($base . '/locks/index.html')) {
        @file_put_contents($base . '/locks/index.html', $forbidden_html);
    }
    if (!file_exists($base . '/locks/.htaccess')) {
        @file_put_contents($base . '/locks/.htaccess', $htaccess);
    }

    $backup = rtrim(app_cfg()['backup_dir'], '/\\');
    if (!is_dir($backup)) {
        @mkdir($backup, 0755, true);
    }

    $logs = rtrim(app_cfg()['logs_dir'], '/\\');
    if (!is_dir($logs)) {
        @mkdir($logs, 0755, true);
    }
    if (!file_exists($logs . '/index.html')) {
        @file_put_contents($logs . '/index.html', $forbidden_html);
    }
    if (!file_exists($logs . '/.htaccess')) {
        @file_put_contents($logs . '/.htaccess', $htaccess);
    }

    $done = true;
}

/**
 * Write (or overwrite) all protective index.html and .htaccess files under
 * the data and logs directories, regardless of whether they already exist.
 *
 * Unlike ensure_storage(), which skips files that are already present, this
 * function always writes so that a restore_backup() call cannot leave stale or
 * tampered protective files in place. It is intentionally idempotent: calling
 * it multiple times produces the same result.
 *
 * @return void
 */
function ensure_protective_files()
{
    $forbidden_html = "<!DOCTYPE html><meta charset=\"utf-8\"><title>Forbidden</title>";
    $htaccess = "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Deny from all\n</IfModule>\n";

    $base = rtrim(data_dir(), '/\\');
    // Always (re)write — do not use file_exists() guards here.
    // data/ root: protects admin_login.json, ratelimit.json, mail.log, etc.
    @file_put_contents($base . '/.htaccess', $htaccess, LOCK_EX);
    @file_put_contents($base . '/index.html', $forbidden_html, LOCK_EX);
    @file_put_contents($base . '/lists/index.html', $forbidden_html, LOCK_EX);

    $logs = rtrim(app_cfg()['logs_dir'], '/\\');
    @file_put_contents($logs . '/index.html', $forbidden_html, LOCK_EX);
    @file_put_contents($logs . '/.htaccess', $htaccess, LOCK_EX);
    @file_put_contents($base . '/locks/index.html', $forbidden_html, LOCK_EX);
    @file_put_contents($base . '/locks/.htaccess', $htaccess, LOCK_EX);
}

/**
 * Get backup directory path.
 *
 * @return string
 */
function backup_dir()
{
    $cfg = app_cfg();
    return rtrim($cfg['backup_dir'], '/\\');
}

/**
 * Get log directory path.
 *
 * @return string
 */
function logs_dir()
{
    $cfg = app_cfg();
    return rtrim($cfg['logs_dir'], '/\\');
}

/**
 * Get the current daily log path.
 *
 * @return string
 */
function daily_log_path()
{
    return logs_dir() . '/' . date('Y-m-d') . '.log';
}

/**
 * Write a single line to the daily application log.
 *
 * @param string $level
 * @param string $message
 * @return void
 */
function app_log($level, $message)
{
    $path = daily_log_path();
    $dir = dirname($path);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $line = date('Y-m-d H:i:s') . ' [' . strtoupper($level) . '] ' . $message . "\n";
    @file_put_contents($path, $line, FILE_APPEND | LOCK_EX);
}

/**
 * Read the last N lines from a log file.
 *
 * @param string $path
 * @param int $lines
 * @return array<int, string>
 */
function read_log_tail($path, $lines = 50)
{
    $meta = read_log_tail_meta($path, $lines, 65536);
    return $meta['lines'];
}

/**
 * Read the last N lines from a log file with a maximum byte limit.
 *
 * @param string $path
 * @param int $lines
 * @param int $maxBytes
 * @return array{lines:array<int,string>,truncated:bool}
 */
function read_log_tail_meta($path, $lines = 50, $maxBytes = 65536)
{
    $result = array();
    if (!is_file($path) || $lines < 1 || $maxBytes < 1) {
        return array('lines' => $result, 'truncated' => false);
    }
    $fp = @fopen($path, 'rb');
    if (!$fp) {
        return array('lines' => $result, 'truncated' => false);
    }
    $bytesScanned = 0;
    $pos = -1;
    $currentLine = '';
    fseek($fp, 0, SEEK_END);
    $fileSize = ftell($fp);
    if ($fileSize === 0) {
        fclose($fp);
        return array('lines' => $result, 'truncated' => false);
    }
    while (count($result) < $lines && -$pos <= $fileSize && $bytesScanned < $maxBytes) {
        fseek($fp, $pos, SEEK_END);
        $char = fgetc($fp);
        $pos--;
        $bytesScanned++;
        if ($char === false) {
            break;
        }
        if ($char === "\n") {
            if ($currentLine !== '') {
                $result[] = strrev($currentLine);
                $currentLine = '';
            }
            continue;
        }
        if ($char === "\r") {
            continue;
        }
        $currentLine .= $char;
    }
    if ($currentLine !== '') {
        $result[] = strrev($currentLine);
    }
    fclose($fp);
    return array(
        'lines' => array_reverse($result),
        'truncated' => $bytesScanned >= $maxBytes && -$pos <= $fileSize,
    );
}

/**
 * Return available backup files sorted newest first.
 *
 * @return array<int, string>
 */
function list_backup_files()
{
    $files = array();
    $path = backup_dir();
    $matches = glob($path . '/backup-*.zip');
    if (!is_array($matches)) {
        return $files;
    }
    foreach ($matches as $file) {
        if (is_file($file)) {
            $files[] = basename($file);
        }
    }
    usort($files, function ($a, $b) {
        return strcmp($b, $a);
    });
    return $files;
}

/**
 * Add a folder and its children to a ZipArchive.
 *
 * @param ZipArchive $zip
 * @param string $folder
 * @param string $basePath
 * @return void
 */
function zip_add_directory(ZipArchive $zip, $folder, $basePath)
{
    $items = scandir($folder);
    if ($items === false) {
        return;
    }
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $path = $folder . '/' . $item;
        $localPath = $basePath . $item;
        if (is_dir($path)) {
            if ($item === 'backups') {
                continue;
            }
            $zip->addEmptyDir($localPath);
            zip_add_directory($zip, $path, $localPath . '/');
        } elseif (is_file($path)) {
            $zip->addFile($path, $localPath);
        }
    }
}

/**
 * Create a zip backup of data storage.
 *
 * @return string|false Backup filename on success or false on failure.
 */
function create_backup_zip()
{
    if (!class_exists('ZipArchive')) {
        return false;
    }
    $backupPath = backup_dir();
    if (!is_dir($backupPath)) {
        @mkdir($backupPath, 0755, true);
    }
    $date = date('Y-m-d');
    $baseName = 'backup-' . $date . '.zip';
    $zipName = $baseName;
    $suffix = 1;
    while (file_exists($backupPath . '/' . $zipName)) {
        $zipName = 'backup-' . $date . '-' . $suffix . '.zip';
        $suffix++;
    }

    $zip = new ZipArchive();
    $fullPath = $backupPath . '/' . $zipName;
    if ($zip->open($fullPath, ZipArchive::CREATE) !== true) {
        return false;
    }
    zip_add_directory($zip, data_dir(), '');
    $zip->close();
    return $fullPath;
}

/**
 * Restore data storage from a backup zip file.
 * Entries are validated against data_dir() to prevent Zip Slip attacks.
 *
 * @param string $backupFile
 * @return bool
 */
function restore_backup($backupFile)
{
    if (!class_exists('ZipArchive')) {
        return false;
    }
    $backupPath = backup_dir();
    $filename = basename($backupFile);
    $fullPath = $backupPath . '/' . $filename;
    if (!file_exists($fullPath) || !is_file($fullPath)) {
        return false;
    }
    $zip = new ZipArchive();
    if ($zip->open($fullPath) !== true) {
        return false;
    }
    $target = rtrim(str_replace('\\', '/', data_dir()), '/') . '/';
    $skipped = 0;
    // Protective filenames that must never be overwritten by a ZIP entry.
    // These files are always regenerated after the restore completes, so
    // skipping them here is safe and prevents a malicious or corrupted backup
    // from replacing the Apache access controls that guard the data directory.
    $protected_names = array('.htaccess', 'index.html');
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $entry = $zip->getNameIndex($i);
        if ($entry === false) {
            continue;
        }
        // Normalize: collapse ../ sequences and strip leading slashes/drive letters
        $norm = str_replace('\\', '/', $entry);
        $norm = preg_replace('/\.\.\//', '', $norm);
        $norm = ltrim($norm, '/');
        if ($norm === '' || substr($norm, -1) === '/') {
            // Directory entry — ensure it exists inside target
            $dir = $target . $norm;
            $real = realpath(dirname(rtrim($dir, '/')));
            $real_target = realpath(rtrim($target, '/'));
            if ($real === false || $real_target === false) {
                continue;
            }
            $real = str_replace('\\', '/', $real);
            $real_target = str_replace('\\', '/', $real_target);
            if (strpos($real . '/', $real_target . '/') !== 0) {
                $skipped++;
                continue;
            }
            @mkdir($dir, 0755, true);
            continue;
        }
        // Skip protective files — they will be force-regenerated after the loop.
        if (in_array(basename($norm), $protected_names, true)) {
            $skipped++;
            app_log('warn', 'restore_backup: skipped protective file ' . $entry);
            continue;
        }
        $dest = $target . $norm;
        // Resolve destination directory
        $dest_dir = dirname($dest);
        if (!is_dir($dest_dir)) {
            @mkdir($dest_dir, 0755, true);
        }
        $real_dest_dir = realpath($dest_dir);
        $real_target = realpath(rtrim($target, '/'));
        if ($real_dest_dir === false || $real_target === false) {
            $skipped++;
            continue;
        }
        $real_dest_dir = str_replace('\\', '/', $real_dest_dir);
        $real_target   = str_replace('\\', '/', $real_target);
        if (strpos($real_dest_dir . '/', $real_target . '/') !== 0) {
            $skipped++;
            app_log('warn', 'restore_backup: blocked unsafe entry ' . $entry);
            continue;
        }
        $stream = $zip->getStream($entry);
        if ($stream === false) {
            continue;
        }
        // Read in chunks and enforce a per-entry size cap (A-5).
        // A legitimate backup entry should never exceed 50 MB; an entry larger
        // than that is most likely a ZIP bomb or a corrupted archive. Accepting
        // it without a limit could exhaust PHP memory on shared hosting.
        $max_entry_bytes = 52428800; // 50 MB
        $contents = '';
        $bytes_read = 0;
        $truncated = false;
        while (!feof($stream)) {
            $chunk = fread($stream, 65536);
            if ($chunk === false) {
                break;
            }
            $bytes_read += strlen($chunk);
            if ($bytes_read > $max_entry_bytes) {
                $truncated = true;
                break;
            }
            $contents .= $chunk;
        }
        fclose($stream);
        if ($truncated) {
            $skipped++;
            app_log('warn', 'restore_backup: skipped oversized entry (>' . ($max_entry_bytes / 1048576) . ' MB) ' . $entry);
            continue;
        }
        file_put_contents($dest, $contents);
    }
    $zip->close();
    // Always regenerate protective files after restoring — this overwrites any
    // tampered copy that may have been in the ZIP before it was skipped, and
    // recreates files that a legitimate but old backup did not include.
    ensure_protective_files();
    if ($skipped > 0) {
        app_log('warn', 'restore_backup: skipped ' . $skipped . ' entries (unsafe or protective) in ' . $filename);
    }
    return true;
}

/**
 * Generate a CSV string of subscribers for a list or all lists.
 *
 * @param string|null $slug
 * @return string|false
 */
function generate_subscribers_csv($slug = null)
{
    $headers = array('list_slug', 'list_name', 'email', 'name', 'status', 'created_at', 'updated_at');
    if ($slug === null || $slug === '') {
        $lists = load_lists();
    } else {
        $list = load_list($slug);
        if (!$list) {
            return false;
        }
        $lists = array($list);
    }
    $stream = fopen('php://temp', 'r+');
    if ($stream === false) {
        return false;
    }
    fputcsv($stream, $headers);
    foreach ($lists as $list) {
        foreach ($list['subscribers'] as $subscriber) {
            $subscriber = ensure_subscriber_defaults($subscriber);
            fputcsv($stream, array(
                $list['slug'],
                $list['name'],
                $subscriber['email'],
                isset($subscriber['name']) ? $subscriber['name'] : '',
                isset($subscriber['status']) ? $subscriber['status'] : '',
                isset($subscriber['created_at']) ? date('c', $subscriber['created_at']) : '',
                isset($subscriber['updated_at']) ? date('c', $subscriber['updated_at']) : '',
            ));
        }
    }
    rewind($stream);
    $csv = stream_get_contents($stream);
    fclose($stream);
    return $csv !== false ? $csv : false;
}

/**
 * Delete a backup file.
 *
 * @param string $backupFile
 * @return bool
 */
function delete_backup_file($backupFile)
{
    $filename = basename($backupFile);
    $fullPath = backup_dir() . '/' . $filename;
    if (is_file($fullPath)) {
        return unlink($fullPath);
    }
    return false;
}

/**
 * Timing-safe string comparison.
 *
 * @param string $a
 * @param string $b
 * @return bool
 */
function secure_equals($a, $b)
{
    $a = (string) $a;
    $b = (string) $b;
    if (function_exists('hash_equals')) {
        return hash_equals($a, $b);
    }
    if (strlen($a) !== strlen($b)) {
        return false;
    }
    $res = 0;
    $len = strlen($a);
    for ($i = 0; $i < $len; $i++) {
        $res |= ord($a[$i]) ^ ord($b[$i]);
    }
    return $res === 0;
}

/**
 * Generate random hex string using a cryptographically secure source.
 *
 * random_bytes() is available on all PHP 7+ installations (the minimum
 * supported by this project), so the legacy fallbacks are retained only for
 * extreme edge cases and are never reached in practice.
 *
 * @param int $length Number of random bytes before hex encoding (output is 2× longer).
 * @return string
 */
function random_hex($length = 16)
{
    $length = max(1, intval($length));
    // PHP 7.0+ always provides random_bytes(); this is the only path taken.
    if (function_exists('random_bytes')) {
        return bin2hex(random_bytes($length));
    }
    // Fallback for environments without random_bytes (should not occur on PHP 7+).
    if (function_exists('openssl_random_pseudo_bytes')) {
        return bin2hex(openssl_random_pseudo_bytes($length));
    }
    // Last-resort fallback — not cryptographically secure.
    $bytes = '';
    while (strlen($bytes) < $length) {
        $bytes .= md5(uniqid('', true) . mt_rand(), true);
    }
    return bin2hex(substr($bytes, 0, $length));
}

/**
 * Get data directory path.
 *
 * @return string
 */
function data_dir()
{
    $cfg = app_cfg();
    return rtrim($cfg['data_dir'], '/\\');
}

/**
 * Get path to a list JSON file.
 *
 * @param string $slug
 * @return string
 */
function list_path($slug)
{
    return data_dir() . '/lists/' . $slug . '.json';
}

/**
 * Normalize a value into a slug.
 *
 * @param string $value
 * @return string
 */
function normalize_slug($value)
{
    $value = strtolower(trim((string) $value));
    $value = preg_replace('/[^a-z0-9]+/', '-', $value);
    $value = trim($value, '-');
    if ($value === '') {
        // random_bytes() is always available on PHP 7+ (the project minimum).
        // 4 bytes → 8 hex chars → "list-xxxxxxxx", matching the previous format
        // while using a cryptographically secure source instead of md5(uniqid()).
        $value = 'list-' . bin2hex(random_bytes(4));
    }
    return $value;
}

/**
 * Validate a slug value.
 *
 * @param string $value
 * @return bool
 */
function valid_slug($value)
{
    return (bool) preg_match('/^[a-z0-9][a-z0-9\-]{2,47}$/', $value);
}

/**
 * Validate that a redirect URL is safe (same host as current HTTP_HOST or app_base_url).
 *
 * @param string $url
 * @return bool
 */
function is_safe_redirect_url($url)
{
    $url = trim((string) $url);
    if ($url === '') {
        return true;
    }
    // Allow relative paths (e.g. index.php, /thanks) but reject protocol-relative URLs (e.g. //attacker.com)
    if (!preg_match('/^https?:\/\//i', $url)) {
        return strpos($url, '//') !== 0;
    }
    $parts = parse_url($url);
    $host = isset($parts['host']) ? strtolower($parts['host']) : '';
    if ($host === '') {
        return true;
    }
    $allowed = array();
    if (!empty($_SERVER['HTTP_HOST'])) {
        $allowed[] = strtolower(explode(':', $_SERVER['HTTP_HOST'])[0]);
    }
    $base_url = app_base_url();
    $base_parts = parse_url($base_url);
    if (!empty($base_parts['host'])) {
        $allowed[] = strtolower($base_parts['host']);
    }
    return in_array($host, $allowed, true);
}

/**
 * Load a JSON file and decode to array.
 *
 * Returns $default when the file does not exist (normal on first run) or when
 * the file exists but contains invalid JSON (indicates corruption, e.g. from a
 * partial write interrupted by a disk-full condition or a server crash).
 * Corruption is distinguished from absence so the event is logged — the admin
 * can then restore from backup or investigate without having to grep logs.
 *
 * @param string $path
 * @param mixed  $default
 * @return mixed
 */
function load_json_file($path, $default)
{
    if (!file_exists($path)) {
        return $default;
    }
    $raw = @file_get_contents($path);
    if ($raw === false) {
        // File exists but could not be read (permissions, race with deletion).
        app_log('error', 'load_json_file: could not read ' . basename($path));
        return $default;
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        // File exists and was read but contains invalid JSON — likely corrupted.
        app_log('error', 'load_json_file: JSON decode failed for ' . basename($path) . ' (last error: ' . json_last_error_msg() . ')');
        return $default;
    }
    return $data;
}

/**
 * Save an array as pretty JSON to file.
 *
 * @param string $path
 * @param array $data
 * @return bool
 */
function save_json_file($path, array $data)
{
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    return file_put_contents($path, $json, LOCK_EX) !== false;
}

/**
 * Create default list structure.
 *
 * @param array $meta
 * @return array
 */
function list_default(array $meta)
{
    $cfg = app_cfg();
    $slug = $meta['slug'];
    $name = $meta['name'];
    return array(
        'slug' => $slug,
        'name' => $name,
        'description' => '',
        'public' => false,
        'created_at' => time(),
        'updated_at' => time(),
        'settings' => array(
            'from_name' => $cfg['from_name'],
            'from_email' => $cfg['from_email'],
            'thank_you_url' => $cfg['default_thank_you'],
        ),
        'messages' => array(),
        'subscribers' => array(),
    );
}

/**
 * Load a list by slug.
 *
 * @param string $slug
 * @return array|null
 */
function load_list($slug)
{
    if (!valid_slug($slug)) {
        return null;
    }
    $data = load_json_file(list_path($slug), null);
    if (!is_array($data)) {
        return null;
    }
    if (!isset($data['settings']) || !is_array($data['settings'])) {
        $data['settings'] = array();
    }
    if (!isset($data['messages']) || !is_array($data['messages'])) {
        $data['messages'] = array();
    }
    if (!isset($data['subscribers']) || !is_array($data['subscribers'])) {
        $data['subscribers'] = array();
    }
    if (!isset($data['slug'])) {
        $data['slug'] = $slug;
    }
    if (!isset($data['name'])) {
        $data['name'] = $slug;
    }
    if (!isset($data['description'])) {
        $data['description'] = '';
    }
    if (!array_key_exists('public', $data)) {
        $data['public'] = false;
    }
    if (!isset($data['updated_at'])) {
        $data['updated_at'] = time();
    }
    return $data;
}

/**
 * Save list array to storage.
 *
 * @param array $list
 * @return bool
 */
function save_list(array $list)
{
    $list['updated_at'] = time();
    return save_json_file(list_path($list['slug']), $list);
}

/**
 * Get path to the per-list auxiliary lock file.
 *
 * A dedicated lock file (instead of locking the JSON itself) keeps a clean
 * separation between advisory locking and the file readers that open the JSON
 * without a lock, and survives list rewrites atomically.
 *
 * @param string $slug
 * @return string
 */
function list_lock_path($slug)
{
    return data_dir() . '/locks/' . $slug . '.lock';
}

/**
 * Run a callback while holding an exclusive lock on a list.
 *
 * Every read-modify-write sequence on a list MUST go through this helper to
 * prevent lost updates when concurrent processes (subscribe.php, unsubscribe.php,
 * cron.php, admin.php) mutate the same list at the same time. The lock is
 * blocking (LOCK_EX without LOCK_NB) so writers serialize cleanly; a 10 second
 * timeout guards against indefinite hangs on broken hosting environments.
 *
 * The callback receives no arguments: it should call load_list()/save_list()
 * (or delete_list()) itself, which operate on the already-unlocked JSON file.
 *
 * @param string   $slug
 * @param callable $callback
 * @return mixed  Whatever the callback returns, or false if the lock failed.
 */
function with_list_lock($slug, $callback)
{
    if (!valid_slug($slug)) {
        return false;
    }
    $path = list_lock_path($slug);
    $dir = dirname($path);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $fp = @fopen($path, 'c');
    if ($fp === false) {
        return false;
    }

    $locked = false;
    $deadline = time() + 10;
    while (time() < $deadline) {
        if (flock($fp, LOCK_EX | LOCK_NB)) {
            $locked = true;
            break;
        }
        usleep(100000); // 100ms
    }
    if (!$locked) {
        // Last resort: blocking flock with the platform default wait.
        $locked = flock($fp, LOCK_EX);
    }
    if (!$locked) {
        fclose($fp);
        return false;
    }

    try {
        $result = call_user_func($callback);
    } catch (Throwable $e) {
        $result = false;
    } finally {
        flock($fp, LOCK_UN);
        fclose($fp);
    }
    return $result;
}

/**
 * Delete list file by slug.
 *
 * @param string $slug
 * @return bool
 */
function delete_list($slug)
{
    $path = list_path($slug);
    if (file_exists($path)) {
        return unlink($path);
    }
    return false;
}

/**
 * Load all lists.
 *
 * Reads every list JSON file in data/lists/ and returns the full list arrays
 * including subscribers and messages. Use this only where the full dataset is
 * required (global send, CSV export). For display-only use cases, prefer
 * load_lists_meta() which skips the subscribers and messages arrays and is
 * significantly faster when lists have many subscribers.
 *
 * @return array
 */
function load_lists()
{
    $items = array();
    foreach (glob(data_dir() . '/lists/*.json') as $file) {
        $base = basename($file, '.json');
        $list = load_list($base);
        if ($list) {
            $items[] = $list;
        }
    }
    usort($items, function ($a, $b) {
        return strcmp($a['name'], $b['name']);
    });
    return $items;
}

/**
 * Load lightweight metadata for all lists — no subscribers, no messages.
 *
 * Reads each list JSON file but returns only the display fields: slug, name,
 * description, public, created_at, updated_at, settings, plus two pre-computed
 * counters (message_count and active_subscriber_count) derived while the full
 * array is still in memory. The subscribers and messages arrays are stripped
 * before returning, keeping peak memory proportional to the number of lists
 * rather than to total subscriber count.
 *
 * Use this in place of load_lists() wherever the full subscriber/message data
 * is not needed — e.g. the public home page, the admin sidebar, and any
 * dropdown that only shows list names.
 *
 * @return array<int, array>  Array of list metadata arrays sorted by name.
 */
function load_lists_meta()
{
    $items = array();
    foreach (glob(data_dir() . '/lists/*.json') as $file) {
        $base = basename($file, '.json');
        $list = load_list($base);
        if (!$list) {
            continue;
        }
        // Compute counters before stripping the arrays.
        $list['_message_count']          = isset($list['messages'])   ? count($list['messages'])   : 0;
        $list['_active_subscriber_count'] = subscriber_count($list, 'active');
        // Strip the large arrays — caller does not need raw records.
        unset($list['subscribers'], $list['messages']);
        $items[] = $list;
    }
    usort($items, function ($a, $b) {
        return strcmp($a['name'], $b['name']);
    });
    return $items;
}

/**
 * Load all list slugs without decoding every list JSON file.
 *
 * @return array
 */
function load_list_slugs()
{
    $slugs = array();
    foreach (glob(data_dir() . '/lists/*.json') as $file) {
        $slugs[] = basename($file, '.json');
    }
    sort($slugs, SORT_STRING);
    return $slugs;
}

/**
 * Generate a short unique id using a cryptographically secure source.
 *
 * @return string 12-character hex string.
 */
function make_id()
{
    // Use random_bytes (always available on PHP 7+) for a proper random ID.
    return substr(bin2hex(random_bytes(8)), 0, 12);
}

/**
 * Find subscriber index in a list by email.
 *
 * @param array $list
 * @param string $email
 * @return int
 */
function list_subscriber_index(array $list, $email)
{
    $needle = strtolower(trim($email));
    foreach ($list['subscribers'] as $index => $subscriber) {
        if (isset($subscriber['email']) && strtolower($subscriber['email']) === $needle) {
            return $index;
        }
    }
    return -1;
}

/**
 * Sanitize text input.
 *
 * @param mixed $value
 * @return string
 */
function sanitize_text($value)
{
    return trim((string) $value);
}

/**
 * Sanitize a short text field and enforce a maximum byte length.
 *
 * Use this for single-line inputs such as names, subjects, and settings fields
 * where unbounded values could waste JSON storage or enable resource exhaustion.
 * Values that exceed $max_length are silently truncated; mb_strimwidth() is used
 * so the result is never cut in the middle of a multi-byte character.
 *
 * @param mixed  $value      Raw input value.
 * @param int    $max_length Maximum number of characters allowed (default: 255).
 * @return string
 */
function sanitize_short_text($value, $max_length = 255)
{
    $value = sanitize_text($value);
    if (mb_strlen($value, 'UTF-8') > $max_length) {
        $value = mb_strimwidth($value, 0, $max_length, '', 'UTF-8');
    }
    return $value;
}

/**
 * Validate that a body/long-text value does not exceed the permitted byte limit.
 *
 * Returns true when the value is within limits, false when it is too large.
 * Callers are responsible for showing the user a meaningful error on false.
 * The limit defaults to 100 KB — large enough for any reasonable email body,
 * small enough to prevent storage exhaustion on shared-hosting JSON files.
 *
 * @param string $value
 * @param int    $max_bytes Maximum byte length (default: 102400 = 100 KB).
 * @return bool
 */
function validate_body_length($value, $max_bytes = 102400)
{
    return strlen($value) <= $max_bytes;
}

/**
 * Sanitize a value for safe use inside an email header.
 *
 * Strips carriage returns and line feeds (both raw and URL-encoded) to prevent
 * CRLF injection attacks where a crafted input could append arbitrary headers
 * such as Bcc: or Content-Type: to an outgoing message. Accepts a string or
 * an array and returns the same type with every element cleaned.
 *
 * @param string|array $value
 * @return string|array
 */
function safe_email_header($value)
{
    if (is_array($value)) {
        return array_map('safe_email_header', $value);
    }
    $value = (string) $value;
    // Remove URL-encoded CR/LF variants before stripping raw characters,
    // so double-encoded payloads (%250a, %250d) do not slip through.
    $value = str_ireplace(array('%0d', '%0a', '%0D', '%0A'), '', $value);
    // Strip raw carriage return and line feed characters.
    $value = str_replace(array("\r", "\n"), '', $value);
    return trim($value);
}

/**
 * Validate and normalize an email address.
 *
 * Accepts only conventional addresses that SMTP servers reliably handle:
 *   - local part: letters, digits, dots, hyphens, plus signs, underscores
 *   - exactly one @ symbol
 *   - domain: one or more labels of letters/digits/hyphens separated by dots
 *   - TLD: two or more letters
 *
 * Rejects quoted strings, comments, IP literals, and any other RFC 5321
 * exotic syntax that breaks real-world SMTP relays and causes delivery issues.
 * Input is trimmed and lower-cased before all checks so the function doubles
 * as a normalizer — callers should use the return value of normalize_email()
 * when they need the canonical form.
 *
 * @param string $email Raw email string from user input.
 * @return bool
 */
function is_valid_email($email)
{
    $email = strtolower(trim((string) $email));
    if ($email === '') {
        return false;
    }
    // Primary check: PHP's built-in filter catches obvious malformed addresses.
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    // Strict allowlist: only plain conventional addresses accepted by SMTP.
    // Rejects quoted locals ("foo bar"@x.com), comments (foo(bar)@x.com),
    // IP literals (foo@[192.168.1.1]), and internationalised domains.
    return (bool) preg_match(
        '/^[a-z0-9][a-z0-9._+\-]*@[a-z0-9]([a-z0-9\-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9\-]*[a-z0-9])?)*\.[a-z]{2,}$/',
        $email
    );
}

/**
 * Normalize an email address to its canonical lower-case trimmed form.
 *
 * Every point that writes an email to storage or computes an HMAC token
 * should pass the address through this function first to ensure consistent
 * casing across all records and prevent logical duplicates.
 *
 * @param string $email
 * @return string
 */
function normalize_email($email)
{
    return strtolower(trim((string) $email));
}

/**
 * Derive the URL installation path from the filesystem.
 *
 * Uses __DIR__ (a PHP compile-time constant, immune to client-supplied headers)
 * relative to DOCUMENT_ROOT to produce the URL subdirectory where the script is
 * installed (e.g. "/autoresponder" or "" for the webroot).
 *
 * Falls back to dirname(SCRIPT_NAME) only when DOCUMENT_ROOT is unavailable
 * (CLI context, exotic server configs). SCRIPT_NAME is a CGI/SAPI variable that
 * can be influenced by PATH_INFO or Host header manipulation in some
 * configurations; __DIR__ is not subject to that class of manipulation.
 *
 * This helper is intentionally package-private (no docblock @api tag) — it exists
 * only to avoid duplicating the same logic in app_base_url() and current_path().
 *
 * @return string  URL path segment, e.g. "/autoresponder" or "". Never ends with "/".
 */
function _app_install_path()
{
    $doc_root    = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim($_SERVER['DOCUMENT_ROOT'], '/\\') : '';
    $install_dir = rtrim(__DIR__, '/\\');

    if ($doc_root !== '' && strpos($install_dir, $doc_root) === 0) {
        // Derive from the filesystem — not influenced by any HTTP header.
        $path = substr($install_dir, strlen($doc_root));
        return rtrim(str_replace('\\', '/', $path), '/');
    }

    // Fallback: CLI or DOCUMENT_ROOT unavailable / outside install dir.
    // SCRIPT_NAME is used here only as a last resort; its dirname gives the
    // script's URL directory, which is equivalent to the install path when
    // each entry-point file lives in the project root.
    return rtrim(str_replace('\\', '/', dirname(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '/')), '/');
}

/**
 * Determine application base URL.
 *
 * Prioritises the explicit 'base_url' config value when set.
 * When auto-detecting, HTTP_HOST is validated against the set of characters
 * allowed in a hostname (RFC 952 / RFC 1123 plus port and IPv6 brackets).
 * If HTTP_HOST is absent or contains unexpected characters, the function falls
 * back to SERVER_NAME and finally to 'localhost', so a crafted Host: header
 * cannot influence the URLs generated for forms, tokens, or asset references.
 *
 * The URL path segment is derived from __DIR__ vs DOCUMENT_ROOT (M-6 fix) so
 * that a manipulated SCRIPT_NAME / PATH_INFO cannot affect the generated URLs.
 *
 * @return string
 */
function app_base_url()
{
    $cfg = app_cfg();
    if (!empty($cfg['base_url'])) {
        return rtrim($cfg['base_url'], '/');
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    $scheme = $https ? 'https' : 'http';

    // Validate HTTP_HOST: only allow hostname characters, dots, hyphens,
    // colons (port separator) and square brackets (IPv6). Fall back to
    // SERVER_NAME, then to 'localhost' if neither is trustworthy.
    $host = '';
    if (!empty($_SERVER['HTTP_HOST'])) {
        $candidate = $_SERVER['HTTP_HOST'];
        if (preg_match('/^[a-zA-Z0-9\-\.\:\[\]]+$/', $candidate)) {
            $host = $candidate;
        }
    }
    if ($host === '' && !empty($_SERVER['SERVER_NAME'])) {
        $candidate = $_SERVER['SERVER_NAME'];
        if (preg_match('/^[a-zA-Z0-9\-\.\:\[\]]+$/', $candidate)) {
            $host = $candidate;
        }
    }
    if ($host === '') {
        $host = 'localhost';
    }

    $dir = _app_install_path();
    return $scheme . '://' . $host . $dir;
}

/**
 * Get current script URL path (installation directory).
 *
 * Uses __DIR__ vs DOCUMENT_ROOT for the path segment (same as app_base_url())
 * so the result is not influenced by client-supplied SCRIPT_NAME or PATH_INFO.
 *
 * @return string  e.g. "/autoresponder" or "/". Never empty.
 */
function current_path()
{
    $dir = _app_install_path();
    return $dir === '' ? '/' : $dir;
}

/**
 * Get or create CSRF token for session.
 *
 * @return string
 */
function csrf_token()
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return '';
    }
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = random_hex(16);
    }
    return $_SESSION['_csrf'];
}

/**
 * Render CSRF hidden input field HTML.
 *
 * @return string
 */
function csrf_field()
{
    $token = htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8');
    return '<input type="hidden" name="_csrf" value="' . $token . '">';
}

/**
 * Check CSRF token from POST against session.
 *
 * @return bool
 */
function csrf_check()
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return false;
    }
    if (empty($_POST['_csrf']) || empty($_SESSION['_csrf'])) {
        return false;
    }
    return secure_equals($_SESSION['_csrf'], $_POST['_csrf']);
}

/**
 * Check if admin is logged in.
 *
 * @return bool
 */
function admin_is_logged_in()
{
    return !empty($_SESSION['admin_logged_in']);
}

/**
 * Require admin login or redirect.
 *
 * @return void
 */
function admin_require_login()
{
    if (!admin_is_logged_in()) {
        header('Location: admin.php');
        exit;
    }
}

/**
 * Return true when the stored admin password value is already a PHP password hash.
 *
 * @param string $stored
 * @return bool
 */
function admin_password_is_hashed($stored)
{
    $stored = (string) $stored;
    if ($stored === '') {
        return false;
    }
    if (strncmp($stored, '$2y$', 4) === 0 || strncmp($stored, '$2a$', 4) === 0 || strncmp($stored, '$2b$', 4) === 0) {
        return true;
    }
    if (strncmp($stored, '$argon2i$', 9) === 0 || strncmp($stored, '$argon2id$', 10) === 0) {
        return true;
    }
    return false;
}

/**
 * Verify an admin password against plain text or hashed storage in config.php.
 *
 * @param string $password
 * @return bool
 */
function admin_verify_password($password)
{
    $cfg = app_cfg();
    $stored = (string) $cfg['admin_password'];
    if (admin_password_is_hashed($stored)) {
        return password_verify((string) $password, $stored);
    }
    return secure_equals($stored, (string) $password);
}

/**
 * Validate admin password (alias for admin_verify_password).
 *
 * @param string $password
 * @return bool
 */
function admin_login_ok($password)
{
    return admin_verify_password($password);
}

/**
 * Max failed admin login attempts before lockout.
 *
 * @return int
 */
function admin_login_max_attempts()
{
    $cfg = app_cfg();
    if (isset($cfg['admin_login_max_attempts'])) {
        return max(1, intval($cfg['admin_login_max_attempts']));
    }
    return 5;
}

/**
 * Admin login lockout duration in seconds.
 *
 * @return int
 */
function admin_login_lock_seconds()
{
    $cfg = app_cfg();
    $minutes = isset($cfg['admin_login_lock_minutes']) ? intval($cfg['admin_login_lock_minutes']) : 15;
    return max(60, $minutes * 60);
}

/**
 * Path to the file-based admin login attempt store.
 *
 * @return string
 */
function admin_login_store_path()
{
    return data_dir() . '/admin_login.json';
}

/**
 * Atomically read, transform, and persist admin login attempt records.
 *
 * Opens the store file once, acquires an exclusive lock, reads the current
 * data, passes it to $transform, and writes back the returned value — all
 * within a single lock window. This eliminates the race condition that existed
 * when admin_login_read_store() and admin_login_write_store() were called
 * separately: between the read-unlock and the write-lock another request
 * could modify the file, causing lost updates or incorrect lockout state.
 *
 * $transform receives the current data array and must return:
 *  - an array  — data is written back to disk and returned.
 *  - null      — no write is performed; null is returned (read-only path).
 *
 * @param callable $transform  function(array $data): array|null
 * @return array|null  The value returned by $transform.
 */
function admin_login_update(callable $transform)
{
    $path = admin_login_store_path();
    $fp = @fopen($path, 'c+');
    if ($fp === false) {
        // Storage unavailable — run transform on empty data without writing.
        return $transform(array());
    }
    if (!flock($fp, LOCK_EX)) {
        fclose($fp);
        return $transform(array());
    }

    rewind($fp);
    $raw = stream_get_contents($fp);
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        $data = array();
    }

    $result = $transform($data);

    if (is_array($result)) {
        $json = json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if ($json !== false) {
            rewind($fp);
            ftruncate($fp, 0);
            fwrite($fp, $json);
            fflush($fp);
        }
    }

    flock($fp, LOCK_UN);
    fclose($fp);
    return $result;
}

/**
 * Resolve client IP for admin login throttling.
 *
 * @return string
 */
function admin_login_client_ip()
{
    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
}

/**
 * Check whether an IP is temporarily locked out from admin login.
 *
 * @param string $ip
 * @param int|null $retry_after Seconds until unlock (set when locked).
 * @return bool
 */
function admin_login_is_locked($ip, &$retry_after = null)
{
    $now = time();
    $locked = false;

    admin_login_update(function (array $data) use ($ip, $now, &$locked, &$retry_after) {
        if (!isset($data[$ip]) || !is_array($data[$ip])) {
            return null; // No record — no write needed.
        }
        $record = $data[$ip];
        $locked_until = isset($record['locked_until']) ? intval($record['locked_until']) : 0;
        if ($locked_until > $now) {
            $retry_after = $locked_until - $now;
            $locked = true;
            return null; // Still locked — no write needed.
        }
        if ($locked_until > 0) {
            // Lock expired — prune the stale record.
            unset($data[$ip]);
            return $data;
        }
        return null;
    });

    return $locked;
}

/**
 * Record a failed admin login attempt for an IP.
 *
 * @param string $ip
 * @return void
 */
function admin_login_record_failure($ip)
{
    $max = admin_login_max_attempts();
    $lock_seconds = admin_login_lock_seconds();
    $now = time();

    admin_login_update(function (array $data) use ($ip, $max, $lock_seconds, $now) {
        $record = isset($data[$ip]) && is_array($data[$ip])
            ? $data[$ip]
            : array('attempts' => 0, 'locked_until' => 0);
        $record['attempts'] = intval(isset($record['attempts']) ? $record['attempts'] : 0) + 1;
        if ($record['attempts'] >= $max) {
            $record['locked_until'] = $now + $lock_seconds;
            app_log('warn', 'Admin login locked IP ' . $ip . ' after ' . $max . ' failed attempts');
        }
        $data[$ip] = $record;
        return $data;
    });
}

/**
 * Clear failed login attempts for an IP after a successful login.
 *
 * @param string $ip
 * @return void
 */
function admin_login_clear_attempts($ip)
{
    admin_login_update(function (array $data) use ($ip) {
        if (!isset($data[$ip])) {
            return null; // Nothing to clear — skip the write.
        }
        unset($data[$ip]);
        return $data;
    });
}

/**
 * Human-readable lockout message for the login form.
 *
 * @param int $retry_after Seconds until unlock.
 * @return string
 */
function admin_login_lock_message($retry_after)
{
    $minutes = max(1, (int) ceil(intval($retry_after) / 60));
    return 'Too many failed login attempts. Please try again in about ' . $minutes . ' minute(s).';
}

/**
 * Replace a plain-text admin_password in config.php with a secure hash.
 *
 * @param string $plain_password Verified plain password from the successful login.
 * @return bool
 */
function admin_password_upgrade_to_hash($plain_password)
{
    if (!function_exists('password_hash')) {
        return false;
    }
    $cfg = app_cfg();
    $stored = (string) $cfg['admin_password'];
    if (admin_password_is_hashed($stored)) {
        return true;
    }
    $hash = password_hash((string) $plain_password, PASSWORD_DEFAULT);
    if ($hash === false || !admin_password_write_config_hash($hash)) {
        return false;
    }
    app_cfg(true);
    app_log('info', 'Admin password auto-hashed in config.php');
    return true;
}

/**
 * Rewrite admin_password in config.php with a hashed value.
 *
 * Uses an atomic write pattern to prevent config.php corruption if the
 * process is interrupted mid-write (disk full, timeout, SIGKILL):
 *  1. Build the new content in memory.
 *  2. Write to a temporary file alongside config.php (same directory,
 *     so rename() is guaranteed to be on the same filesystem).
 *  3. Rename the temporary file over config.php atomically.
 *
 * On Linux/macOS rename() is atomic at the kernel level. On Windows it is
 * not atomic but is still safer than direct overwrite: PHP's rename() calls
 * MoveFileEx which replaces the target in a single operation. If rename()
 * fails (e.g. permissions), the original config.php is untouched.
 *
 * @param string $hash
 * @return bool
 */
function admin_password_write_config_hash($hash)
{
    $path = __DIR__ . '/config.php';
    $content = @file_get_contents($path);
    if ($content === false) {
        return false;
    }
    $hash = (string) $hash;
    $replaced = 0;
    $new = preg_replace_callback(
        "/('admin_password'\\s*=>\\s*)'(?:\\\\'|[^']*)'/",
        function ($m) use ($hash) {
            $escaped = str_replace(array('\\', "'"), array('\\\\', "\\'"), $hash);
            return $m[1] . "'" . $escaped . "'";
        },
        $content,
        1,
        $replaced
    );
    if ($replaced !== 1) {
        $new = preg_replace_callback(
            '/("admin_password"\\s*=>\\s*)"(?:\\\\"|[^"]*)"/',
            function ($m) use ($hash) {
                $escaped = str_replace(array('\\', '"'), array('\\\\', '\\"'), $hash);
                return $m[1] . '"' . $escaped . '"';
            },
            $content,
            1,
            $replaced
        );
    }
    if ($replaced !== 1) {
        return false;
    }

    // Write to a temp file in the same directory so rename() stays on the
    // same filesystem (required for atomic rename on Linux).
    $tmp = $path . '.tmp';
    if (@file_put_contents($tmp, $new, LOCK_EX) === false) {
        @unlink($tmp);
        return false;
    }

    // Verify the temp file was written completely before replacing the original.
    if (@filesize($tmp) !== strlen($new)) {
        @unlink($tmp);
        return false;
    }

    if (!@rename($tmp, $path)) {
        // rename() can fail on Windows if another process has config.php open.
        // Fall back to direct overwrite — still safer than losing the temp file.
        @unlink($tmp);
        return @file_put_contents($path, $new, LOCK_EX) !== false;
    }

    return true;
}

/**
 * Encode subject for email headers.
 *
 * @param string $subject
 * @return string
 */
function encode_subject($subject)
{
    $subject = (string) $subject;
    if ($subject === '') {
        return '';
    }
    if (function_exists('mb_encode_mimeheader')) {
        return mb_encode_mimeheader($subject, 'UTF-8', 'B', "\r\n");
    }
    return $subject;
}

/**
 * Classify SMTP responses so quota exhaustion can be handled without
 * incrementing bounce/failure logic.
 *
 * This function is the ONLY point that converts raw SMTP server text into a
 * value stored in subscriber records or queue items. It intentionally returns
 * a small closed set of string constants ('quota_exceeded', 'smtp_temporary',
 * 'smtp_permanent', null) — never the raw SMTP response text.
 *
 * This is a deliberate security boundary (B-3): raw SMTP responses are
 * already bounded to 513 bytes per line by fgets($socket, 514) in
 * smtp_get_response(), but they are never persisted to JSON regardless.
 * Callers must not bypass this function by writing $response directly into
 * subscriber['last_error'], queue item['last_error'], or any other stored field.
 *
 * @param string $response  Raw SMTP response string from smtp_get_response().
 * @return string|null      One of: 'quota_exceeded', 'smtp_temporary',
 *                          'smtp_permanent', or null (unclassified / not an error).
 */
function smtp_response_error_code($response)
{
    $text = strtolower((string) $response);
    if ($text === '') {
        return null;
    }
    if (
        strpos($text, 'quota') !== false ||
        strpos($text, 'daily limit') !== false ||
        strpos($text, 'limit exceeded') !== false ||
        strpos($text, 'too many emails') !== false ||
        strpos($text, 'message limit') !== false ||
        strpos($text, 'exceeded') !== false
    ) {
        return 'quota_exceeded';
    }
    if (preg_match('/^4[0-9]{2}\b/', $text)) {
        return 'smtp_temporary';
    }
    if (preg_match('/^5[0-9]{2}\b/', $text)) {
        return 'smtp_permanent';
    }
    return null;
}

/**
 * Send a plain-text email over SMTP.
 *
 * @param string $to
 * @param string $subject
 * @param string $body
 * @param string $from_name
 * @param string $from_email
 * @param string|null $error_code
 * @return bool
 */
function smtp_send_mail($to, $subject, $body, $from_name, $from_email, &$error_code = null)
{
    $error_code = null;
    // --- Defense in depth: strip CRLF from every value that lands in a header.
    $to         = safe_email_header($to);
    $subject    = safe_email_header($subject);
    $from_name  = safe_email_header($from_name);
    $from_email = safe_email_header($from_email);

    // Reject clearly invalid envelope addresses before opening a socket.
    if (!filter_var($to, FILTER_VALIDATE_EMAIL) || !filter_var($from_email, FILTER_VALIDATE_EMAIL)) {
        log_mail_event('error', 'smtp_send_mail: invalid address to=' . $to . ' from=' . $from_email);
        $error_code = 'smtp_failed';
        return false;
    }

    $cfg = app_cfg();
    $host = isset($cfg['smtp_host']) ? trim($cfg['smtp_host']) : '';
    $port = isset($cfg['smtp_port']) ? intval($cfg['smtp_port']) : 587;
    $user = isset($cfg['smtp_username']) ? $cfg['smtp_username'] : '';
    $pass = isset($cfg['smtp_password']) ? $cfg['smtp_password'] : '';
    $secure = isset($cfg['smtp_secure']) ? strtolower(trim($cfg['smtp_secure'])) : '';
    if ($host === '') {
        $error_code = 'smtp_failed';
        return false;
    }

    $remote = ($secure === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port;
    $socket = @stream_socket_client($remote, $errno, $errstr, 30, STREAM_CLIENT_CONNECT);
    if (!$socket) {
        log_mail_event('error', 'SMTP connect failed: ' . $errno . ' ' . $errstr);
        $error_code = 'smtp_failed';
        return false;
    }
    stream_set_timeout($socket, 30);

    $response = smtp_get_response($socket);
    if (substr($response, 0, 3) !== '220') {
        fclose($socket);
        log_mail_event('error', 'SMTP connect response invalid: ' . $response);
        $error_code = smtp_response_error_code($response) ?: 'smtp_failed';
        return false;
    }

    $hostname = preg_replace('/[^A-Za-z0-9\.\-]/', '-', php_uname('n') ?: 'localhost');
    if (!smtp_put_line($socket, 'EHLO ' . $hostname)) {
        fclose($socket);
        log_mail_event('error', 'SMTP write failed during EHLO');
        return false;
    }
    $response = smtp_get_response($socket);
    if (substr($response, 0, 3) !== '250') {
        fclose($socket);
        log_mail_event('error', 'SMTP EHLO failed: ' . $response);
        $error_code = smtp_response_error_code($response) ?: 'smtp_failed';
        return false;
    }

    if ($secure === 'tls') {
        if (!smtp_put_line($socket, 'STARTTLS')) {
            fclose($socket);
            log_mail_event('error', 'SMTP write failed during STARTTLS');
            $error_code = 'smtp_failed';
            return false;
        }
        $response = smtp_get_response($socket);
        if (substr($response, 0, 3) !== '220' || !stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            fclose($socket);
            log_mail_event('error', 'SMTP STARTTLS failed: ' . $response);
            $error_code = smtp_response_error_code($response) ?: 'smtp_failed';
            return false;
        }
        if (!smtp_put_line($socket, 'EHLO ' . $hostname)) {
            fclose($socket);
            log_mail_event('error', 'SMTP write failed during EHLO after STARTTLS');
            $error_code = 'smtp_failed';
            return false;
        }
        $response = smtp_get_response($socket);
        if (substr($response, 0, 3) !== '250') {
            fclose($socket);
            log_mail_event('error', 'SMTP EHLO after STARTTLS failed: ' . $response);
            $error_code = smtp_response_error_code($response) ?: 'smtp_failed';
            return false;
        }
    }

    if ($user !== '' && $pass !== '') {
        if (!smtp_put_line($socket, 'AUTH LOGIN')) {
            fclose($socket);
            log_mail_event('error', 'SMTP write failed during AUTH LOGIN');
            $error_code = 'smtp_failed';
            return false;
        }
        $response = smtp_get_response($socket);
        if (substr($response, 0, 3) !== '334') {
            fclose($socket);
            log_mail_event('error', 'SMTP AUTH LOGIN failed: ' . $response);
            $error_code = smtp_response_error_code($response) ?: 'smtp_failed';
            return false;
        }
        if (!smtp_put_line($socket, base64_encode($user))) {
            fclose($socket);
            log_mail_event('error', 'SMTP write failed during username send');
            $error_code = 'smtp_failed';
            return false;
        }
        $response = smtp_get_response($socket);
        if (substr($response, 0, 3) !== '334') {
            fclose($socket);
            log_mail_event('error', 'SMTP username rejected: ' . $response);
            $error_code = smtp_response_error_code($response) ?: 'smtp_failed';
            return false;
        }
        if (!smtp_put_line($socket, base64_encode($pass))) {
            fclose($socket);
            log_mail_event('error', 'SMTP write failed during password send');
            $error_code = 'smtp_failed';
            return false;
        }
        $response = smtp_get_response($socket);
        if (substr($response, 0, 3) !== '235') {
            fclose($socket);
            log_mail_event('error', 'SMTP authentication failed: ' . $response);
            $error_code = smtp_response_error_code($response) ?: 'smtp_failed';
            return false;
        }
    }

    $from = '<' . $from_email . '>';
    $to_address = '<' . $to . '>';
    if (!smtp_put_line($socket, 'MAIL FROM:' . $from)) {
        fclose($socket);
        log_mail_event('error', 'SMTP write failed during MAIL FROM');
        $error_code = 'smtp_failed';
        return false;
    }
    $response = smtp_get_response($socket);
    if (substr($response, 0, 3) !== '250') {
        fclose($socket);
        log_mail_event('error', 'SMTP MAIL FROM failed: ' . $response);
        $error_code = smtp_response_error_code($response) ?: 'smtp_failed';
        return false;
    }
    if (!smtp_put_line($socket, 'RCPT TO:' . $to_address)) {
        fclose($socket);
        log_mail_event('error', 'SMTP write failed during RCPT TO');
        $error_code = 'smtp_failed';
        return false;
    }
    $response = smtp_get_response($socket);
    if (substr($response, 0, 3) !== '250' && substr($response, 0, 3) !== '251') {
        fclose($socket);
        log_mail_event('error', 'SMTP RCPT TO failed: ' . $response);
        $error_code = smtp_response_error_code($response) ?: 'smtp_failed';
        return false;
    }
    if (!smtp_put_line($socket, 'DATA')) {
        fclose($socket);
        log_mail_event('error', 'SMTP write failed during DATA');
        $error_code = 'smtp_failed';
        return false;
    }
    $response = smtp_get_response($socket);
    if (substr($response, 0, 3) !== '354') {
        fclose($socket);
        log_mail_event('error', 'SMTP DATA failed: ' . $response);
        $error_code = smtp_response_error_code($response) ?: 'smtp_failed';
        return false;
    }

    $headers = array();
    $headers[] = 'Date: ' . gmdate('D, d M Y H:i:s') . ' +0000';
    // Encode the display name with MIME Base64 to safely carry accents, emoji,
    // and any other non-ASCII characters without risking header injection.
    $from_display = $from_name !== '' ? encode_subject($from_name) . ' <' . $from_email . '>' : '<' . $from_email . '>';
    $headers[] = 'From: ' . $from_display;
    $headers[] = 'To: ' . $to;
    $headers[] = 'Reply-To: ' . $from_email;
    $headers[] = 'Subject: ' . encode_subject($subject);
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'Content-Type: text/plain; charset=UTF-8';
    $headers[] = 'Content-Transfer-Encoding: 8bit';
    $headers[] = 'X-Mailer: PHP/' . phpversion();

    $data = implode("\r\n", $headers) . "\r\n\r\n" . $body;
    $data = str_replace("\r\n.", "\r\n..", str_replace("\n.", "\n..", $data));
    if (!smtp_put_line($socket, $data)) {
        fclose($socket);
        log_mail_event('error', 'SMTP write failed during message body');
        $error_code = 'smtp_failed';
        return false;
    }
    if (!smtp_put_line($socket, '.')) {
        fclose($socket);
        log_mail_event('error', 'SMTP write failed during end-of-data marker');
        $error_code = 'smtp_failed';
        return false;
    }
    $response = smtp_get_response($socket);
    if (substr($response, 0, 3) !== '250') {
        fclose($socket);
        log_mail_event('error', 'SMTP message send failed: ' . $response);
        $error_code = smtp_response_error_code($response) ?: 'smtp_failed';
        return false;
    }

    smtp_put_line($socket, 'QUIT');
    fclose($socket);
    return true;
}

/**
 * Send a raw SMTP command to the socket.
 *
 * @param resource $socket
 * @param string $line
 * @return bool  True on success, false if the socket write fails
 */
function smtp_put_line($socket, $line)
{
    $buffer = (string) $line . "\r\n";
    while ($buffer !== '') {
        $written = fwrite($socket, $buffer);
        if ($written === false) {
            return false;
        }
        if ($written === 0) {
            usleep(10000);
            continue;
        }
        $buffer = (string) substr($buffer, $written);
    }
    return true;
}

/**
 * Read response lines from the SMTP socket.
 *
 * Breaks the read loop immediately when the stream reports a timeout so that
 * the cron process does not hang indefinitely on a silent or slow SMTP server.
 * The caller must close the socket and log the condition when an empty string
 * is returned mid-conversation.
 *
 * @param resource $socket
 * @return string
 */
function smtp_get_response($socket)
{
    $response = '';
    while (!feof($socket)) {
        $line = fgets($socket, 514);
        // Detect stream-level read timeout (stream_set_timeout value was
        // exceeded). fgets returns false OR an empty string on timeout
        // depending on the PHP version; checking meta_data is authoritative.
        $meta = stream_get_meta_data($socket);
        if (!empty($meta['timed_out'])) {
            // Return whatever was accumulated (may be empty). The caller will
            // see a response that does not match any expected SMTP code and
            // handle the error path, closing the socket cleanly.
            break;
        }
        if ($line === false) {
            break;
        }
        $response .= $line;
        if (preg_match('/^[0-9]{3} /', $line)) {
            break;
        }
    }
    return trim($response);
}

/**
 * Send a plain-text email using PHP mail() or SMTP when enabled.
 *
 * The message body is always delivered as 'text/plain'. The $body parameter
 * must be a plain-text string; no HTML markup or encoding wrappers should be
 * applied by the caller.
 *
 * @param string $to
 * @param string $subject
 * @param string $body
 * @param string|null $from_name
 * @param string|null $from_email
 * @param string|null $error_code
 * @return bool
 */
function send_mail_text($to, $subject, $body, $from_name = null, $from_email = null, &$error_code = null)
{
    $error_code = null;
    $cfg = app_cfg();
    $from_name  = $from_name  ? $from_name  : $cfg['from_name'];
    $from_email = $from_email ? $from_email : $cfg['from_email'];

    // Defense in depth: strip CRLF from every header value at the transport layer
    // regardless of what the caller already did — prevents injection via config values.
    $to         = safe_email_header($to);
    $subject    = safe_email_header($subject);
    $from_name  = safe_email_header($from_name);
    $from_email = safe_email_header($from_email);

    // Reject invalid envelope addresses before sending anything.
    if (!filter_var($to, FILTER_VALIDATE_EMAIL) || !filter_var($from_email, FILTER_VALIDATE_EMAIL)) {
        log_mail_event('error', 'send_mail_text: invalid address to=' . $to . ' from=' . $from_email);
        $error_code = 'smtp_failed';
        return false;
    }

    if (!empty($cfg['smtp_enabled']) && !empty($cfg['smtp_host'])) {
        // smtp_send_mail applies its own safe_email_header pass; values are
        // already clean here but a second pass is harmless and ensures the
        // internal contract holds even if the call graph changes later.
        return smtp_send_mail($to, $subject, $body, $from_name, $from_email, $error_code);
    }

    // Encode the display name to safely carry non-ASCII characters.
    $from_display = $from_name !== '' ? encode_subject($from_name) . ' <' . $from_email . '>' : '<' . $from_email . '>';

    $headers = array();
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'Content-Type: text/plain; charset=UTF-8';
    $headers[] = 'From: ' . $from_display;
    $headers[] = 'Reply-To: ' . $from_email;
    $headers[] = 'X-Mailer: PHP/' . phpversion();

    $ok = @mail($to, encode_subject($subject), $body, implode("\r\n", $headers));
    if (!$ok) {
        $error_code = 'smtp_failed';
    }
    return $ok;
}

/**
 * Append an entry to mail log file.
 *
 * @param string $level
 * @param string $message
 * @return void
 */
function log_mail_event($level, $message)
{
    $cfg = app_cfg();
    $path = isset($cfg['mail_log']) ? $cfg['mail_log'] : data_dir() . '/mail.log';
    $line = date('Y-m-d H:i:s') . ' [' . strtoupper($level) . '] ' . $message . "\n";
    @file_put_contents($path, $line, FILE_APPEND | LOCK_EX);
}

/**
 * Return the configured daily SMTP send limit.
 *
 * @return int
 */
function smtp_daily_limit()
{
    $cfg = app_cfg();
    return isset($cfg['smtp_daily_limit']) ? intval($cfg['smtp_daily_limit']) : 0;
}

/**
 * Get the path to the persistent send queue/state file.
 *
 * @return string
 */
function mail_queue_path()
{
    return data_dir() . '/locks/queue.json';
}

/**
 * Build a default mail queue structure.
 *
 * @return array
 */
function mail_queue_default()
{
    return array(
        'state' => array(
            'date' => date('Y-m-d'),
            'sent' => 0,
            'quota_exhausted' => false,
            'quota_reason' => '',
            'updated_at' => time(),
        ),
        'items' => array(),
    );
}

/**
 * Load the persistent mail queue and state.
 *
 * @return array
 */
function mail_queue_load()
{
    $path = mail_queue_path();
    if (!file_exists($path)) {
        return mail_queue_default();
    }
    $raw = @file_get_contents($path);
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        return mail_queue_default();
    }
    if (!isset($data['state']) || !is_array($data['state'])) {
        $data['state'] = array();
    }
    if (!isset($data['items']) || !is_array($data['items'])) {
        $data['items'] = array();
    }
    return $data;
}

/**
 * Persist the mail queue and state.
 *
 * @param array $queue
 * @return bool
 */
function mail_queue_save(array $queue)
{
    $path = mail_queue_path();
    $dir = dirname($path);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    return save_json_file($path, $queue);
}

/**
 * Run a callback while holding an exclusive lock on the mail queue file.
 *
 * Every operation that reads queue.json, modifies it in memory, and writes it
 * back MUST go through this helper to prevent lost updates when concurrent
 * processes (admin send_global and cron.php) access the queue simultaneously.
 *
 * Without this lock, two concurrent callers can both load the same queue state,
 * make independent modifications, and the last writer silently discards the
 * other's changes — items enqueued by send_global can disappear if cron.php
 * saves its own version a millisecond later (B-6).
 *
 * The lock file is data/locks/queue.lock — separate from queue.json itself so
 * advisory locking does not interfere with readers that open the JSON directly
 * (e.g. the admin panel stat display, which reads without modifying).
 *
 * @param callable $callback  function(): mixed  Called while the lock is held.
 *                            Should call mail_queue_load() / mail_queue_save()
 *                            itself — this helper only manages the lock.
 * @return mixed  Whatever the callback returns, or false if the lock failed.
 */
function with_queue_lock(callable $callback)
{
    $lock_path = data_dir() . '/locks/queue.lock';
    $dir = dirname($lock_path);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $fp = @fopen($lock_path, 'c');
    if ($fp === false) {
        // Cannot create lock file — run without lock rather than blocking all
        // queue operations. Log the condition so the admin is aware.
        app_log('warn', 'with_queue_lock: could not open lock file, proceeding without lock');
        return call_user_func($callback);
    }
    if (!flock($fp, LOCK_EX)) {
        fclose($fp);
        app_log('warn', 'with_queue_lock: could not acquire lock, proceeding without lock');
        return call_user_func($callback);
    }
    try {
        $result = call_user_func($callback);
    } catch (Throwable $e) {
        $result = false;
    } finally {
        flock($fp, LOCK_UN);
        fclose($fp);
    }
    return $result;
}

/**
 * Reset queue state when the day changes.
 *
 * @param array $queue
 * @param int|null $now
 * @return void
 */
function mail_queue_sync_state(array &$queue, $now = null)
{
    if ($now === null) {
        $now = time();
    }
    $today = date('Y-m-d', $now);
    if (!isset($queue['state']) || !is_array($queue['state'])) {
        $queue['state'] = array();
    }
    if (!isset($queue['state']['date']) || $queue['state']['date'] !== $today) {
        $queue['state'] = array(
            'date' => $today,
            'sent' => 0,
            'quota_exhausted' => false,
            'quota_reason' => '',
            'updated_at' => $now,
        );
        return;
    }
    if (!isset($queue['state']['sent'])) {
        $queue['state']['sent'] = 0;
    }
    if (!array_key_exists('quota_exhausted', $queue['state'])) {
        $queue['state']['quota_exhausted'] = false;
    }
    if (!array_key_exists('quota_reason', $queue['state'])) {
        $queue['state']['quota_reason'] = '';
    }
    $queue['state']['updated_at'] = $now;
}

/**
 * Get the next local midnight for deferred mail.
 *
 * @param int|null $now
 * @return int
 */
function mail_queue_next_reset_at($now = null)
{
    if ($now === null) {
        $now = time();
    }
    return strtotime('tomorrow midnight', $now);
}

/**
 * Return the remaining local daily budget.
 *
 * @param array|null $queue
 * @param int|null $now
 * @return int
 */
function mail_budget_remaining($queue = null, $now = null)
{
    $limit = smtp_daily_limit();
    if ($limit <= 0) {
        return -1;
    }
    if ($queue === null) {
        $queue = mail_queue_load();
    }
    mail_queue_sync_state($queue, $now);
    $sent = isset($queue['state']['sent']) ? intval($queue['state']['sent']) : 0;
    return max(0, $limit - $sent);
}

/**
 * Consume one unit from the daily budget if available.
 *
 * @param array $queue
 * @param int $amount
 * @param int|null $now
 * @return bool
 */
function mail_budget_consume(array &$queue, $amount = 1, $now = null)
{
    $limit = smtp_daily_limit();
    if ($limit <= 0) {
        return true;
    }
    mail_queue_sync_state($queue, $now);
    $sent = isset($queue['state']['sent']) ? intval($queue['state']['sent']) : 0;
    if ($sent + $amount > $limit) {
        $queue['state']['quota_exhausted'] = true;
        if (empty($queue['state']['quota_reason'])) {
            $queue['state']['quota_reason'] = 'local_daily_limit';
        }
        return false;
    }
    $queue['state']['sent'] = $sent + $amount;
    $queue['state']['updated_at'] = $now === null ? time() : $now;
    return true;
}

/**
 * Mark the queue as quota-exhausted for the day.
 *
 * @param array $queue
 * @param string $reason
 * @param int|null $now
 * @return void
 */
function mail_budget_mark_exhausted(array &$queue, $reason = '', $now = null)
{
    mail_queue_sync_state($queue, $now);
    $queue['state']['quota_exhausted'] = true;
    $queue['state']['quota_reason'] = $reason !== '' ? $reason : 'quota_exceeded';
    $queue['state']['updated_at'] = $now === null ? time() : $now;
}

/**
 * Add one or more items to the persistent queue.
 *
 * Enforces a configurable cap (mail_queue_max_items in config.php, default 10 000)
 * to prevent unbounded disk and memory growth. Items are rejected — not silently
 * dropped — when the cap is reached: the function logs a warning and returns false
 * so the caller (send_global) can surface the condition to the admin. Items that
 * would individually exceed the cap mid-batch are also rejected; items already
 * accepted in the same call are still persisted (partial enqueue is logged).
 *
 * The entire load → modify → save sequence runs inside with_queue_lock() (B-6)
 * so a concurrent admin send_global and cron execution cannot produce a lost
 * update where one caller's enqueued items are silently discarded by the other.
 *
 * @param array<int,array> $items
 * @return bool  True if all items were enqueued, false if the cap was hit.
 */
function mail_queue_enqueue_items(array $items)
{
    if (empty($items)) {
        return true;
    }
    return with_queue_lock(function () use ($items) {
        $queue = mail_queue_load();
        mail_queue_sync_state($queue);
        $now = time();

        // Enforce the queue size cap (M-2).
        $cfg = app_cfg();
        $max_items = isset($cfg['mail_queue_max_items']) ? intval($cfg['mail_queue_max_items']) : 10000;
        $current_count = count($queue['items']);

        if ($max_items > 0 && $current_count >= $max_items) {
            app_log('warn', 'mail_queue_enqueue_items: queue cap reached (' . $current_count . '/' . $max_items . '), enqueue rejected for ' . count($items) . ' item(s)');
            return false;
        }

        $existing_keys = array();
        foreach ($queue['items'] as $queued_item) {
            if (is_array($queued_item) && !empty($queued_item['dedupe_key'])) {
                $existing_keys[$queued_item['dedupe_key']] = true;
            }
        }

        $cap_hit = false;
        $accepted = 0;
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }
            // Stop adding items if the cap is reached mid-batch.
            if ($max_items > 0 && ($current_count + $accepted) >= $max_items) {
                $cap_hit = true;
                break;
            }
            $dedupe_key = hash(
                'sha256',
                implode('|', array(
                    isset($item['kind']) ? (string) $item['kind'] : 'global',
                    isset($item['to']) ? strtolower(trim((string) $item['to'])) : '',
                    isset($item['subject']) ? (string) $item['subject'] : '',
                    isset($item['body']) ? (string) $item['body'] : '',
                    isset($item['from_name']) ? (string) $item['from_name'] : '',
                    isset($item['from_email']) ? strtolower(trim((string) $item['from_email'])) : '',
                    isset($item['list_slug']) ? (string) $item['list_slug'] : '',
                ))
            );
            if (isset($existing_keys[$dedupe_key])) {
                continue;
            }
            $item += array(
                'id' => make_id(),
                'kind' => 'global',
                'created_at' => $now,
                'due_at' => $now,
                'attempts' => 0,
                'last_error' => '',
                'dedupe_key' => $dedupe_key,
            );
            $existing_keys[$dedupe_key] = true;
            $queue['items'][] = $item;
            $accepted++;
        }

        if ($cap_hit) {
            $remaining = count($items) - $accepted;
            app_log('warn', 'mail_queue_enqueue_items: queue cap (' . $max_items . ') reached mid-batch — accepted ' . $accepted . ', rejected ' . $remaining . ' item(s)');
        }

        $queue['state']['updated_at'] = $now;
        $saved = mail_queue_save($queue);
        // Return false if the cap was hit, even if the accepted items were saved,
        // so the caller knows the full batch was not enqueued.
        return $saved && !$cap_hit;
    });
}

/**
 * Queue helper for a single deferred mail job.
 *
 * @param array $item
 * @return bool
 */
function mail_queue_enqueue_item(array $item)
{
    return mail_queue_enqueue_items(array($item));
}

/**
 * Process pending queue items up to the remaining daily budget.
 *
 * The entire load → process → save sequence runs inside with_queue_lock() (B-6)
 * so a concurrent admin send_global cannot enqueue new items while this function
 * is mid-run and produce a lost update where its items are discarded when
 * mail_queue_save() writes back the state snapshot loaded at the start.
 *
 * @param int|null $now
 * @return array{sent:int,failed:int,queued:int,quota_exhausted:bool}
 */
function mail_queue_process($now = null)
{
    if ($now === null) {
        $now = time();
    }
    // Capture $now before the lock so the timestamp is consistent even if
    // acquiring the lock takes a few milliseconds.
    return with_queue_lock(function () use ($now) {
        $queue = mail_queue_load();
        mail_queue_sync_state($queue, $now);
        $cfg = app_cfg();
        $delay_seconds = isset($cfg['send_delay_seconds']) ? intval($cfg['send_delay_seconds']) : 0;
        $items = isset($queue['items']) && is_array($queue['items']) ? $queue['items'] : array();
        $remaining_items = array();
        $sent = 0;
        $failed = 0;
        $quota_exhausted = false;
        $next_reset_at = mail_queue_next_reset_at($now);

        foreach ($items as $index => $item) {
            if (!is_array($item)) {
                continue;
            }
            $due_at = isset($item['due_at']) ? intval($item['due_at']) : 0;
            if ($due_at > $now) {
                $remaining_items[] = $item;
                continue;
            }

            if (!mail_budget_consume($queue, 1, $now)) {
                $quota_exhausted = true;
                $item['due_at'] = $next_reset_at;
                $remaining_items[] = $item;
                for ($j = $index + 1; $j < count($items); $j++) {
                    if (isset($items[$j]) && is_array($items[$j])) {
                        $items[$j]['due_at'] = $next_reset_at;
                        $remaining_items[] = $items[$j];
                    }
                }
                break;
            }

            $error_code = null;
            $ok = send_mail_text(
                isset($item['to']) ? $item['to'] : '',
                isset($item['subject']) ? $item['subject'] : '',
                isset($item['body']) ? $item['body'] : '',
                isset($item['from_name']) ? $item['from_name'] : null,
                isset($item['from_email']) ? $item['from_email'] : null,
                $error_code
            );
            if ($ok) {
                $sent++;
                app_log('info', 'Queued mail sent to=' . (isset($item['to']) ? $item['to'] : '?') . (isset($item['list_slug']) ? ' list=' . $item['list_slug'] : ''));
                if ($delay_seconds > 0) {
                    sleep($delay_seconds);
                }
                continue;
            }

            if ($error_code === 'quota_exceeded') {
                $quota_exhausted = true;
                mail_budget_mark_exhausted($queue, $error_code, $now);
                app_log('warn', 'SMTP daily quota exhausted while sending to=' . (isset($item['to']) ? $item['to'] : '?') . (isset($item['list_slug']) ? ' list=' . $item['list_slug'] : ''));
                $item['due_at'] = $next_reset_at;
                $remaining_items[] = $item;
                for ($j = $index + 1; $j < count($items); $j++) {
                    if (isset($items[$j]) && is_array($items[$j])) {
                        $items[$j]['due_at'] = $next_reset_at;
                        $remaining_items[] = $items[$j];
                    }
                }
                break;
            }

            $failed++;
            $item['attempts'] = isset($item['attempts']) ? intval($item['attempts']) + 1 : 1;
            $item['last_error'] = $error_code !== null ? $error_code : 'smtp_failed';
            app_log('error', 'Queued mail failed to=' . (isset($item['to']) ? $item['to'] : '?') . ' error=' . $item['last_error'] . (isset($item['list_slug']) ? ' list=' . $item['list_slug'] : ''));
            if ($error_code !== 'smtp_permanent') {
                $item['due_at'] = $next_reset_at;
                $remaining_items[] = $item;
            } elseif (!empty($item['retry_on_fail'])) {
                $item['due_at'] = $next_reset_at;
                $remaining_items[] = $item;
            }
            if ($delay_seconds > 0) {
                sleep($delay_seconds);
            }
        }

        $queue['items'] = array_values($remaining_items);
        $queue['state']['updated_at'] = $now;
        mail_queue_save($queue);

        return array(
            'sent' => $sent,
            'failed' => $failed,
            'queued' => count($queue['items']),
            'quota_exhausted' => $quota_exhausted,
        );
    });
}

/**
 * Create unsubscribe token for an email.
 *
 * @param string $email
 * @return string
 */
function unsubscribe_token($email)
{
    $cfg = app_cfg();
    return hash_hmac('sha256', strtolower(trim($email)), $cfg['unsubscribe_secret']);
}

/**
 * Create public form token for a list slug.
 *
 * @param string $slug
 * @return string
 */
function public_form_token($slug)
{
    $cfg = app_cfg();
    return hash_hmac('sha256', 'form:' . $slug, $cfg['unsubscribe_secret']);
}

/**
 * Validate public form token.
 *
 * @param string $slug
 * @param string $token
 * @return bool
 */
function public_form_token_valid($slug, $token)
{
    return secure_equals(public_form_token($slug), (string) $token);
}

/**
 * Rate limit: check and increment counter for an IP address.
 * Uses a simple file-based store in the data directory.
 *
 * Fail-open design: if ratelimit.json cannot be opened (e.g. the data
 * directory temporarily loses write permissions on shared hosting), the
 * request is allowed through rather than blocking all legitimate subscribers.
 * The failure is logged AND recorded in a separate status flag file
 * (data/ratelimit_error.json) so the admin panel can display a visible
 * warning without requiring the admin to check server logs.
 *
 * @param string $ip
 * @return bool True if allowed, false if rate limit exceeded
 */
function rate_limit_check_and_increment($ip)
{
    $cfg = app_cfg();
    $max = isset($cfg['rate_limit_max']) ? intval($cfg['rate_limit_max']) : 10;
    $window = isset($cfg['rate_limit_window']) ? intval($cfg['rate_limit_window']) : 3600;
    $path = data_dir() . '/ratelimit.json';
    $now = time();

    $fp = @fopen($path, 'c+');
    if ($fp === false) {
        // Fail-open: allow the request rather than blocking all subscribers when
        // the data directory loses write permissions. Log the condition AND write
        // a persistent status flag so the admin panel can surface a visible
        // warning without requiring log access.
        app_log('warn', 'rate_limit_check_and_increment: could not open ' . $path . ' — rate limiting disabled for IP ' . $ip);
        rate_limit_record_storage_error();
        return true;
    }

    // Storage is working — clear any previously recorded error flag.
    rate_limit_clear_storage_error();

    flock($fp, LOCK_EX);

    $raw = stream_get_contents($fp);
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        $data = array();
    }

    // Clean expired entries
    foreach ($data as $k => $v) {
        if (!isset($v['window_start']) || ($v['window_start'] + $window) <= $now) {
            unset($data[$k]);
        }
    }

    $record = isset($data[$ip]) && is_array($data[$ip]) ? $data[$ip] : null;
    if ($record === null || !isset($record['count'], $record['window_start']) || ($record['window_start'] + $window) <= $now) {
        $data[$ip] = array('count' => 1, 'window_start' => $now);
        $allowed = true;
    } elseif (intval($record['count']) >= $max) {
        log_mail_event('warn', 'Rate limit exceeded for IP ' . $ip . ' count=' . intval($record['count']) . ' max=' . $max);
        $allowed = false;
    } else {
        $data[$ip]['count'] = intval($data[$ip]['count']) + 1;
        $allowed = true;
    }

    if ($allowed) {
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    flock($fp, LOCK_UN);
    fclose($fp);
    return $allowed;
}

/**
 * Get all rate limit records.
 *
 * @return array<string,array{count:int,window_start:int}>
 */
function rate_limit_get_all()
{
    $path = data_dir() . '/ratelimit.json';
    if (!file_exists($path)) {
        return array();
    }
    $raw = @file_get_contents($path);
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        return array();
    }
    return $decoded;
}

/**
 * Clear rate limit records. If $ip is provided clears single IP, otherwise clears all.
 *
 * Uses the same fopen('c+') + flock(LOCK_EX) pattern as rate_limit_check_and_increment()
 * to prevent a race condition between the read and the write. Without this lock, a
 * concurrent subscription request could write an updated counter between the moment
 * this function reads the file and the moment it overwrites it, causing the new counter
 * to be silently discarded or the cleared IP to reappear with stale data.
 *
 * The "clear all" path truncates the file to zero bytes under the same exclusive lock
 * instead of using unlink(), which avoids a race with any process that already has an
 * open file descriptor and would write back to the now-deleted path.
 *
 * @param string|null $ip
 * @return void
 */
function rate_limit_clear($ip = null)
{
    $path = data_dir() . '/ratelimit.json';

    $fp = @fopen($path, 'c+');
    if ($fp === false) {
        // File does not exist or is not writable — nothing to clear.
        return;
    }
    flock($fp, LOCK_EX);

    if ($ip === null) {
        // Clear all: truncate the file to zero bytes under the lock so any
        // concurrent reader gets an empty document rather than stale data.
        ftruncate($fp, 0);
    } else {
        $raw = stream_get_contents($fp);
        $data = json_decode($raw, true);
        if (is_array($data) && isset($data[$ip])) {
            unset($data[$ip]);
            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
    }

    flock($fp, LOCK_UN);
    fclose($fp);
}

/**
 * Record a rate-limit storage failure so the admin panel can show a warning.
 *
 * Writes a small JSON flag to data/ratelimit_error.json. This file is
 * intentionally separate from ratelimit.json so that a write failure on the
 * main rate-limit file does not also prevent recording the diagnostic flag.
 * If even this secondary write fails, the failure remains log-only — we never
 * risk an infinite error loop.
 *
 * @return void
 */
function rate_limit_record_storage_error()
{
    $flag_path = data_dir() . '/ratelimit_error.json';
    $data = array(
        'storage_error' => true,
        'first_seen_at' => time(),
        'message'       => 'ratelimit.json could not be opened — rate limiting is disabled. Check data/ directory permissions.',
    );
    // If the flag already exists, preserve the original first_seen_at timestamp.
    if (file_exists($flag_path)) {
        $existing = @json_decode(@file_get_contents($flag_path), true);
        if (is_array($existing) && isset($existing['first_seen_at'])) {
            $data['first_seen_at'] = $existing['first_seen_at'];
        }
    }
    @file_put_contents($flag_path, json_encode($data, JSON_PRETTY_PRINT), LOCK_EX);
}

/**
 * Clear the rate-limit storage error flag once the storage is working again.
 *
 * Called on every successful fopen() of ratelimit.json so the admin panel
 * warning disappears automatically as soon as permissions are restored.
 *
 * @return void
 */
function rate_limit_clear_storage_error()
{
    $flag_path = data_dir() . '/ratelimit_error.json';
    if (file_exists($flag_path)) {
        @unlink($flag_path);
    }
}

/**
 * Return the rate-limit storage error state, or null if no error is recorded.
 *
 * @return array|null  Associative array with 'storage_error', 'first_seen_at',
 *                     'message' keys, or null if no error flag exists.
 */
function rate_limit_get_storage_error()
{
    $flag_path = data_dir() . '/ratelimit_error.json';
    if (!file_exists($flag_path)) {
        return null;
    }
    $data = @json_decode(@file_get_contents($flag_path), true);
    return is_array($data) ? $data : null;
}

/**
 * Build unsubscribe URL for a subscriber.
 *
 * @param string $list_slug
 * @param string $email
 * @return string
 */
function unsubscribe_url($list_slug, $email)
{
    return app_base_url() . '/unsubscribe.php?list=' . rawurlencode($list_slug) . '&email=' . rawurlencode($email) . '&token=' . rawurlencode(unsubscribe_token($email));
}

/**
 * Merge template tokens into text.
 *
 * @param string $text
 * @param array $list
 * @param array $subscriber
 * @return string
 */
function merge_template($text, array $list, array $subscriber)
{
    $name = isset($subscriber['name']) ? $subscriber['name'] : '';
    $name_parts = explode(' ', trim($name));
    $first = isset($name_parts[0]) ? $name_parts[0] : '';
    $replacements = array(
        '{{NAME}}' => $name,
        '{{FIRSTNAME}}' => $first,
        '{{EMAIL}}' => isset($subscriber['email']) ? $subscriber['email'] : '',
        '{{LIST}}' => isset($list['name']) ? $list['name'] : '',
        '{{UNSUBSCRIBE_URL}}' => unsubscribe_url($list['slug'], $subscriber['email']),
        '{{SITE_URL}}' => app_base_url(),
    );
    return strtr((string) $text, $replacements);
}

/**
 * Emit HTTP security headers for HTML responses.
 *
 * Called once by render_header() before any output is sent. Separated into its
 * own function so it can be unit-tested and overridden independently.
 *
 * Headers applied:
 *  - Content-Security-Policy: restricts resource origins. 'unsafe-inline' is
 *    no longer required for script-src since the admin JS was externalised to
 *    admin.js (audit T-1). style-src retains 'unsafe-inline' for inline styles
 *    in style.css and the maintenance/error pages which do not load external
 *    stylesheets.
 *  - X-Frame-Options: DENY — prevents clickjacking via iframe embedding.
 *  - X-Content-Type-Options: nosniff — disables MIME-type sniffing on responses.
 *  - Referrer-Policy: strict-origin-when-cross-origin — limits referrer leakage
 *    to same-origin full URL; cross-origin requests receive only the origin.
 *  - Permissions-Policy: opts out of browser features not used by the admin panel.
 *
 * @return void
 */
function emit_security_headers()
{
    if (headers_sent()) {
        return;
    }
    // CSP: all resources are self-hosted. Script-src no longer requires
    // 'unsafe-inline' now that the admin panel JS has been externalised to
    // admin.js (audit T-1). Style-src retains 'unsafe-inline' for the inline
    // styles used in style.css and the maintenance pages.
    header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header("Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()");
}

/**
 * Render HTML header.
 *
 * @param string $title
 * @param string $active
 * @return void
 */
function render_header($title, $active = '')
{
    $cfg = app_cfg();
    if (!headers_sent()) {
        header('Content-Type: text/html; charset=UTF-8');
        emit_security_headers();
    }
    $site = 'Autoresponder';
    $description = 'The Ultralight Autoresponder Designed for Simplicity';
    $title = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
    $base = htmlspecialchars(app_base_url(), ENT_QUOTES, 'UTF-8');
    $is_logged_in = function_exists('admin_is_logged_in') && admin_is_logged_in();
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    echo '<title>' . $title . ' | ' . $site . '</title>';
    echo '<link rel="stylesheet" href="style.css">';
    echo '<link rel="apple-touch-icon" sizes="180x180" href="' . $base . '/img/apple-touch-icon.png">';
    echo '<link rel="icon" type="image/png" sizes="32x32" href="' . $base . '/img/favicon-32x32.png">';
    echo '<link rel="icon" type="image/png" sizes="16x16" href="' . $base . '/img/favicon-16x16.png">';
    echo '<link rel="shortcut icon" href="' . $base . '/img/favicon.ico">';
    echo '<link rel="manifest" href="' . $base . '/img/site.webmanifest">';
    echo '</head><body><div class="wrap">';
    echo '<div class="hero">';
    
    echo '<div class="hero-top"><div><h1><a class="hero__link" href="https://autoresponder.vip">' . '<img class="logo" src="' . $base . '/img/android-chrome-192x192.png" alt="Autoresponder.vip logo" width="45">' . '<span class="brand-text">' . $site . '<span class="logo__ext">.vip</span></span>' . '</a></h1><div class="muted">' . $description . '</div></div>';

    echo '<div class="hero-actions">';
    echo '<a class="btn secondary" href="' . $base . '/">Public</a>';
    echo '<a class="btn secondary" href="' . $base . '/admin.php">Admin</a>';
    if ($is_logged_in) {
        // Append the current CSRF token to the logout URL so the handler can
        // verify it and reject forced-logout attacks via crafted <img> tags or
        // third-party links (CSRF via GET).
        $logout_token = htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8');
        echo '<a class="btn secondary" href="' . $base . '/admin.php?logout=1&amp;_csrf=' . $logout_token . '">Logout</a>';
    }
    echo '</div></div>';
    echo '</div><div class="spacer"></div>';
}

/**
 * Render HTML footer.
 *
 * @return void
 */
function render_footer()
{
    echo '</div></div></body></html>';
}

/**
 * Count messages in a list.
 *
 * @param array $list
 * @return int
 */
function message_count($list)
{
    return isset($list['messages']) ? count($list['messages']) : 0;
}

/**
 * Count subscribers optionally filtered by status.
 *
 * @param array $list
 * @param string|null $status
 * @return int
 */
function subscriber_count($list, $status = null)
{
    $count = 0;
    if (empty($list['subscribers'])) {
        return 0;
    }
    foreach ($list['subscribers'] as $subscriber) {
        if ($status === null || (isset($subscriber['status']) && $subscriber['status'] === $status)) {
            $count++;
        }
    }
    return $count;
}

/**
 * Ensure subscriber array contains default keys.
 *
 * @param array $subscriber
 * @return array
 */
function ensure_subscriber_defaults(array $subscriber)
{
    $subscriber += array(
        'name' => '',
        'email' => '',
        'status' => 'active',
        'next_message_index' => 0,
        'next_send_at' => 0,
        'created_at' => time(),
        'updated_at' => time(),
        'last_sent_at' => 0,
        'last_error' => '',
        'fail_count' => 0,
        'bounce_reason' => '',
        'token' => '',
    );
    if (empty($subscriber['token']) && !empty($subscriber['email'])) {
        $subscriber['token'] = unsubscribe_token($subscriber['email']);
    }
    return $subscriber;
}

/**
 * Defer a subscriber until the next day without marking a bounce.
 *
 * @param array $subscriber
 * @param int|null $now
 * @return void
 */
function defer_subscriber_until_tomorrow(array &$subscriber, $now = null)
{
    if ($now === null) {
        $now = time();
    }
    $subscriber = ensure_subscriber_defaults($subscriber);
    $subscriber['next_send_at'] = mail_queue_next_reset_at($now);
    $subscriber['last_error'] = 'daily_quota_exhausted';
    $subscriber['updated_at'] = $now;
}

/**
 * Dispatch queued messages for a single subscriber.
 *
 * The caller is responsible for loading, syncing, and saving $queue_state.
 * This function only reads and mutates the state in memory via
 * mail_budget_consume(); it never touches the filesystem directly.
 *
 * @param array      $list
 * @param array      $subscriber
 * @param array      $queue_state  Mail queue state (passed by reference; mutated by mail_budget_consume)
 * @param int|null   $now
 * @param int|null   $max_sends
 * @param int|null   $sent_ref     Running total of sends in the current cycle
 * @param bool|null  $quota_exhausted  Set to true when the daily budget is used up
 * @return int  Number of messages sent for this subscriber
 */
function dispatch_subscriber(array &$list, array &$subscriber, array &$queue_state, $now = null, $max_sends = null, &$sent_ref = null, &$quota_exhausted = null)
{
    if ($now === null) {
        $now = time();
    }
    $quota_exhausted = false;
    $sent = 0;
    $messages = isset($list['messages']) ? $list['messages'] : array();
    $message_total = count($messages);
    $subscriber = ensure_subscriber_defaults($subscriber);
    $cfg = app_cfg();
    $delay_seconds = isset($cfg['send_delay_seconds']) ? intval($cfg['send_delay_seconds']) : 0;
    $bounce_threshold = isset($cfg['bounce_threshold']) ? intval($cfg['bounce_threshold']) : 3;
    while ($subscriber['status'] === 'active' && $subscriber['next_message_index'] < $message_total && intval($subscriber['next_send_at']) <= $now) {
        $message_index = intval($subscriber['next_message_index']);
        if (!isset($messages[$message_index])) {
            break;
        }
        $message = $messages[$message_index];
        $subject = merge_template(isset($message['subject']) ? $message['subject'] : '', $list, $subscriber);
        $body = merge_template(isset($message['body']) ? $message['body'] : '', $list, $subscriber);
        if ($max_sends !== null && isset($sent_ref) && $sent_ref !== null && $sent_ref >= $max_sends) {
            break;
        }
        if (!mail_budget_consume($queue_state, 1, $now)) {
            defer_subscriber_until_tomorrow($subscriber, $now);
            $quota_exhausted = true;
            break;
        }
        // Send the message body as plain text — no HTML encoding needed.
        // htmlspecialchars() is intentionally omitted: in a text/plain message
        // the SMTP transport treats the body as literal characters, so there is
        // no HTML execution surface and encoding would corrupt special characters
        // (e.g. '&' → '&amp;') visible to the reader.
        $smtp_error = null;
        $headers_ok = send_mail_text($subscriber['email'], $subject, $body, $list['settings']['from_name'], $list['settings']['from_email'], $smtp_error);
        if (!$headers_ok) {
            if ($smtp_error === 'quota_exceeded' || $smtp_error === 'smtp_temporary' || $smtp_error === 'smtp_failed') {
                defer_subscriber_until_tomorrow($subscriber, $now);
                if ($smtp_error === 'quota_exceeded') {
                    $quota_exhausted = true;
                }
                break;
            }
            $subscriber['last_error'] = 'mail_failed';
            $subscriber['fail_count'] = isset($subscriber['fail_count']) ? intval($subscriber['fail_count']) + 1 : 1;
            $subscriber['bounce_reason'] = 'mail_failed';
            $subscriber['updated_at'] = $now;
            log_mail_event('error', 'Mail failed to ' . $subscriber['email'] . ' list=' . $list['slug'] . ' subject=' . $subject);
            app_log('error', 'Mail send failed list=' . $list['slug'] . ' to=' . $subscriber['email'] . ' subject=' . str_replace(array("\r", "\n"), ' ', $subject));
            if ($subscriber['fail_count'] >= $bounce_threshold) {
                $subscriber['status'] = 'bounced';
                log_mail_event('info', 'Marked bounced: ' . $subscriber['email'] . ' after ' . $subscriber['fail_count'] . ' failures');
            }
            break;
        }
        app_log('info', 'Email sent list=' . $list['slug'] . ' to=' . $subscriber['email'] . ' subject=' . str_replace(array("\r", "\n"), ' ', $subject));
        $sent++;
        if (isset($sent_ref) && $sent_ref !== null) {
            $sent_ref++;
        }
        $subscriber['last_sent_at'] = $now;
        $subscriber['last_error'] = '';
        $subscriber['fail_count'] = 0;
        $subscriber['bounce_reason'] = '';
        $subscriber['next_message_index'] = $message_index + 1;
        if ($subscriber['next_message_index'] < $message_total) {
            $next_message = $messages[$subscriber['next_message_index']];
            $delay = isset($next_message['delay_days']) ? intval($next_message['delay_days']) : 0;
            if ($delay < 0) {
                $delay = 0;
            }
            $subscriber['next_send_at'] = $now + ($delay * 86400);
        } else {
            $subscriber['next_send_at'] = 0;
        }
        $subscriber['updated_at'] = $now;
        if ($delay_seconds > 0) {
            sleep($delay_seconds);
        }
        if ($subscriber['next_send_at'] > $now) {
            break;
        }
    }
    return $sent;
}

/**
 * Run delivery cycle for all lists.
 *
 * Each list is processed while holding its exclusive lock, so a concurrent
 * subscribe/unsubscribe or admin edit cannot lose its update against the
 * delivery run. The list is reloaded fresh inside the lock (it may have changed
 * since the initial snapshot). Partial progress is always persisted before
 * releasing the lock, even when max_sends_per_run stops the run early.
 *
 * @return array{sent:int,log:array}
 */
function run_delivery_cycle()
{
    $list_slugs = load_list_slugs();
    $now = time();
    $log = array();
    $total_sent = 0;
    $cfg = app_cfg();
    $max_per_run = isset($cfg['max_sends_per_run']) ? intval($cfg['max_sends_per_run']) : 0;
    $sent_counter = 0;
    $stop = false;
    $mail_queue_state_cache = mail_queue_load();
    mail_queue_sync_state($mail_queue_state_cache, $now);
    $quota_exhausted = false;

    foreach ($list_slugs as $slug) {
        if ($stop || $quota_exhausted) {
            break;
        }
        with_list_lock($slug, function () use (
            $slug, $now, $max_per_run, &$log, &$total_sent, &$sent_counter, &$stop, &$quota_exhausted, &$mail_queue_state_cache
        ) {
            // Reload fresh inside the lock; the snapshot may be stale by now.
            $list = load_list($slug);
            if (!$list) {
                $log[] = $slug . ': list not found';
                return;
            }
            $changed = false;
            foreach ($list['subscribers'] as $sindex => $subscriber) {
                $subscriber = ensure_subscriber_defaults($subscriber);
                if ($subscriber['status'] !== 'active') {
                    continue;
                }
                if (intval($subscriber['next_send_at']) > $now) {
                    continue;
                }
                $before = $subscriber;
                $max_sends_arg = ($max_per_run > 0 ? $max_per_run : null);
                $quota_hit = false;
                $sent = dispatch_subscriber($list, $subscriber, $mail_queue_state_cache, $now, $max_sends_arg, $sent_counter, $quota_hit);
                if ($quota_hit) {
                    $quota_exhausted = true;
                }
                if ($sent > 0 || $subscriber != $before) {
                    $changed = true;
                }
                // Always write the updated subscriber state back to $list before
                // any save or early-exit so the record is never lost.
                $list['subscribers'][$sindex] = $subscriber;
                $total_sent += $sent;
                if ($quota_exhausted) {
                    save_list($list);
                    $changed = false;
                    $stop = true;
                    break;
                }
                if ($max_per_run > 0 && $sent_counter >= $max_per_run) {
                    // Persist immediately before breaking so that progress made
                    // in this iteration is never silently discarded. Without this
                    // explicit save the next cron run would reprocess the same
                    // subscribers and deliver duplicate messages.
                    save_list($list);
                    $changed = false; // Mark clean — save already done above.
                    $stop = true;
                    break;
                }
            }
            if ($changed) {
                save_list($list);
            }
            $log[] = $slug . ': ' . subscriber_count($list, 'active') . ' active';
        });
    }
    mail_queue_save($mail_queue_state_cache);
    if ($stop && !$quota_exhausted) {
        $log[] = 'Reached max sends per run (' . intval($max_per_run) . '), stopping early.';
    }
    if ($quota_exhausted) {
        $log[] = 'Daily SMTP quota exhausted; deferred remaining sends until tomorrow.';
    }
    return array('sent' => $total_sent, 'log' => $log);
}
